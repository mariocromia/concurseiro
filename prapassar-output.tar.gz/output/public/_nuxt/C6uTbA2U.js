import{B as Ne,u as Ue,r as G,a8 as Be,a0 as ce,f as Fe,s as W,C as qe,E as Pe,b as de,w as ue,T as fe,G as He,o as w,c as k,k as K,a,t as O,l as d,p as Ke,v as Ve,F as ne,z as ae,x as Z,d as ee,m as Ye,_ as Je}from"#entry";var he;(function(e){e.STRING="string",e.NUMBER="number",e.INTEGER="integer",e.BOOLEAN="boolean",e.ARRAY="array",e.OBJECT="object"})(he||(he={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var pe;(function(e){e.LANGUAGE_UNSPECIFIED="language_unspecified",e.PYTHON="python"})(pe||(pe={}));var me;(function(e){e.OUTCOME_UNSPECIFIED="outcome_unspecified",e.OUTCOME_OK="outcome_ok",e.OUTCOME_FAILED="outcome_failed",e.OUTCOME_DEADLINE_EXCEEDED="outcome_deadline_exceeded"})(me||(me={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ge=["user","model","function","system"];var ve;(function(e){e.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",e.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",e.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",e.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",e.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",e.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY"})(ve||(ve={}));var xe;(function(e){e.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",e.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",e.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",e.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",e.BLOCK_NONE="BLOCK_NONE"})(xe||(xe={}));var ye;(function(e){e.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",e.NEGLIGIBLE="NEGLIGIBLE",e.LOW="LOW",e.MEDIUM="MEDIUM",e.HIGH="HIGH"})(ye||(ye={}));var Ee;(function(e){e.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",e.SAFETY="SAFETY",e.OTHER="OTHER"})(Ee||(Ee={}));var J;(function(e){e.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",e.STOP="STOP",e.MAX_TOKENS="MAX_TOKENS",e.SAFETY="SAFETY",e.RECITATION="RECITATION",e.LANGUAGE="LANGUAGE",e.BLOCKLIST="BLOCKLIST",e.PROHIBITED_CONTENT="PROHIBITED_CONTENT",e.SPII="SPII",e.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",e.OTHER="OTHER"})(J||(J={}));var be;(function(e){e.TASK_TYPE_UNSPECIFIED="TASK_TYPE_UNSPECIFIED",e.RETRIEVAL_QUERY="RETRIEVAL_QUERY",e.RETRIEVAL_DOCUMENT="RETRIEVAL_DOCUMENT",e.SEMANTIC_SIMILARITY="SEMANTIC_SIMILARITY",e.CLASSIFICATION="CLASSIFICATION",e.CLUSTERING="CLUSTERING"})(be||(be={}));var _e;(function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.AUTO="AUTO",e.ANY="ANY",e.NONE="NONE"})(_e||(_e={}));var we;(function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.MODE_DYNAMIC="MODE_DYNAMIC"})(we||(we={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class T extends Error{constructor(o){super(`[GoogleGenerativeAI Error]: ${o}`)}}class V extends T{constructor(o,t){super(o),this.response=t}}class Te extends T{constructor(o,t,s,r){super(o),this.status=t,this.statusText=s,this.errorDetails=r}}class B extends T{}class Me extends T{}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ze="https://generativelanguage.googleapis.com",Qe="v1beta",Xe="0.24.1",We="genai-js";var P;(function(e){e.GENERATE_CONTENT="generateContent",e.STREAM_GENERATE_CONTENT="streamGenerateContent",e.COUNT_TOKENS="countTokens",e.EMBED_CONTENT="embedContent",e.BATCH_EMBED_CONTENTS="batchEmbedContents"})(P||(P={}));class Ze{constructor(o,t,s,r,n){this.model=o,this.task=t,this.apiKey=s,this.stream=r,this.requestOptions=n}toString(){var o,t;const s=((o=this.requestOptions)===null||o===void 0?void 0:o.apiVersion)||Qe;let n=`${((t=this.requestOptions)===null||t===void 0?void 0:t.baseUrl)||ze}/${s}/${this.model}:${this.task}`;return this.stream&&(n+="?alt=sse"),n}}function et(e){const o=[];return e?.apiClient&&o.push(e.apiClient),o.push(`${We}/${Xe}`),o.join(" ")}async function tt(e){var o;const t=new Headers;t.append("Content-Type","application/json"),t.append("x-goog-api-client",et(e.requestOptions)),t.append("x-goog-api-key",e.apiKey);let s=(o=e.requestOptions)===null||o===void 0?void 0:o.customHeaders;if(s){if(!(s instanceof Headers))try{s=new Headers(s)}catch(r){throw new B(`unable to convert customHeaders value ${JSON.stringify(s)} to Headers: ${r.message}`)}for(const[r,n]of s.entries()){if(r==="x-goog-api-key")throw new B(`Cannot set reserved header name ${r}`);if(r==="x-goog-api-client")throw new B(`Header name ${r} can only be set using the apiClient field`);t.append(r,n)}}return t}async function ot(e,o,t,s,r,n){const i=new Ze(e,o,t,s,n);return{url:i.toString(),fetchOptions:Object.assign(Object.assign({},at(n)),{method:"POST",headers:await tt(i),body:r})}}async function X(e,o,t,s,r,n={},i=fetch){const{url:u,fetchOptions:p}=await ot(e,o,t,s,r,n);return st(u,p,i)}async function st(e,o,t=fetch){let s;try{s=await t(e,o)}catch(r){rt(r,e)}return s.ok||await nt(s,e),s}function rt(e,o){let t=e;throw t.name==="AbortError"?(t=new Me(`Request aborted when fetching ${o.toString()}: ${e.message}`),t.stack=e.stack):e instanceof Te||e instanceof B||(t=new T(`Error fetching from ${o.toString()}: ${e.message}`),t.stack=e.stack),t}async function nt(e,o){let t="",s;try{const r=await e.json();t=r.error.message,r.error.details&&(t+=` ${JSON.stringify(r.error.details)}`,s=r.error.details)}catch{}throw new Te(`Error fetching from ${o.toString()}: [${e.status} ${e.statusText}] ${t}`,e.status,e.statusText,s)}function at(e){const o={};if(e?.signal!==void 0||e?.timeout>=0){const t=new AbortController;e?.timeout>=0&&setTimeout(()=>t.abort(),e.timeout),e?.signal&&e.signal.addEventListener("abort",()=>{t.abort()}),o.signal=t.signal}return o}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ie(e){return e.text=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning text from the first candidate only. Access response.candidates directly to use the other candidates.`),te(e.candidates[0]))throw new V(`${U(e)}`,e);return it(e)}else if(e.promptFeedback)throw new V(`Text not available. ${U(e)}`,e);return""},e.functionCall=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),te(e.candidates[0]))throw new V(`${U(e)}`,e);return console.warn("response.functionCall() is deprecated. Use response.functionCalls() instead."),Ce(e)[0]}else if(e.promptFeedback)throw new V(`Function call not available. ${U(e)}`,e)},e.functionCalls=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),te(e.candidates[0]))throw new V(`${U(e)}`,e);return Ce(e)}else if(e.promptFeedback)throw new V(`Function call not available. ${U(e)}`,e)},e}function it(e){var o,t,s,r;const n=[];if(!((t=(o=e.candidates)===null||o===void 0?void 0:o[0].content)===null||t===void 0)&&t.parts)for(const i of(r=(s=e.candidates)===null||s===void 0?void 0:s[0].content)===null||r===void 0?void 0:r.parts)i.text&&n.push(i.text),i.executableCode&&n.push("\n```"+i.executableCode.language+`
`+i.executableCode.code+"\n```\n"),i.codeExecutionResult&&n.push("\n```\n"+i.codeExecutionResult.output+"\n```\n");return n.length>0?n.join(""):""}function Ce(e){var o,t,s,r;const n=[];if(!((t=(o=e.candidates)===null||o===void 0?void 0:o[0].content)===null||t===void 0)&&t.parts)for(const i of(r=(s=e.candidates)===null||s===void 0?void 0:s[0].content)===null||r===void 0?void 0:r.parts)i.functionCall&&n.push(i.functionCall);if(n.length>0)return n}const lt=[J.RECITATION,J.SAFETY,J.LANGUAGE];function te(e){return!!e.finishReason&&lt.includes(e.finishReason)}function U(e){var o,t,s;let r="";if((!e.candidates||e.candidates.length===0)&&e.promptFeedback)r+="Response was blocked",!((o=e.promptFeedback)===null||o===void 0)&&o.blockReason&&(r+=` due to ${e.promptFeedback.blockReason}`),!((t=e.promptFeedback)===null||t===void 0)&&t.blockReasonMessage&&(r+=`: ${e.promptFeedback.blockReasonMessage}`);else if(!((s=e.candidates)===null||s===void 0)&&s[0]){const n=e.candidates[0];te(n)&&(r+=`Candidate was blocked due to ${n.finishReason}`,n.finishMessage&&(r+=`: ${n.finishMessage}`))}return r}function z(e){return this instanceof z?(this.v=e,this):new z(e)}function ct(e,o,t){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var s=t.apply(e,o||[]),r,n=[];return r={},i("next"),i("throw"),i("return"),r[Symbol.asyncIterator]=function(){return this},r;function i(g){s[g]&&(r[g]=function(h){return new Promise(function(y,M){n.push([g,h,y,M])>1||u(g,h)})})}function u(g,h){try{p(s[g](h))}catch(y){b(n[0][3],y)}}function p(g){g.value instanceof z?Promise.resolve(g.value.v).then(R,_):b(n[0][2],g)}function R(g){u("next",g)}function _(g){u("throw",g)}function b(g,h){g(h),n.shift(),n.length&&u(n[0][0],n[0][1])}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ae=/^data\: (.*)(?:\n\n|\r\r|\r\n\r\n)/;function dt(e){const o=e.body.pipeThrough(new TextDecoderStream("utf8",{fatal:!0})),t=ht(o),[s,r]=t.tee();return{stream:ft(s),response:ut(r)}}async function ut(e){const o=[],t=e.getReader();for(;;){const{done:s,value:r}=await t.read();if(s)return ie(pt(o));o.push(r)}}function ft(e){return ct(this,arguments,function*(){const t=e.getReader();for(;;){const{value:s,done:r}=yield z(t.read());if(r)break;yield yield z(ie(s))}})}function ht(e){const o=e.getReader();return new ReadableStream({start(s){let r="";return n();function n(){return o.read().then(({value:i,done:u})=>{if(u){if(r.trim()){s.error(new T("Failed to parse stream"));return}s.close();return}r+=i;let p=r.match(Ae),R;for(;p;){try{R=JSON.parse(p[1])}catch{s.error(new T(`Error parsing JSON response: "${p[1]}"`));return}s.enqueue(R),r=r.substring(p[0].length),p=r.match(Ae)}return n()}).catch(i=>{let u=i;throw u.stack=i.stack,u.name==="AbortError"?u=new Me("Request aborted when reading from the stream"):u=new T("Error reading from the stream"),u})}}})}function pt(e){const o=e[e.length-1],t={promptFeedback:o?.promptFeedback};for(const s of e){if(s.candidates){let r=0;for(const n of s.candidates)if(t.candidates||(t.candidates=[]),t.candidates[r]||(t.candidates[r]={index:r}),t.candidates[r].citationMetadata=n.citationMetadata,t.candidates[r].groundingMetadata=n.groundingMetadata,t.candidates[r].finishReason=n.finishReason,t.candidates[r].finishMessage=n.finishMessage,t.candidates[r].safetyRatings=n.safetyRatings,n.content&&n.content.parts){t.candidates[r].content||(t.candidates[r].content={role:n.content.role||"user",parts:[]});const i={};for(const u of n.content.parts)u.text&&(i.text=u.text),u.functionCall&&(i.functionCall=u.functionCall),u.executableCode&&(i.executableCode=u.executableCode),u.codeExecutionResult&&(i.codeExecutionResult=u.codeExecutionResult),Object.keys(i).length===0&&(i.text=""),t.candidates[r].content.parts.push(i)}r++}s.usageMetadata&&(t.usageMetadata=s.usageMetadata)}return t}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ge(e,o,t,s){const r=await X(o,P.STREAM_GENERATE_CONTENT,e,!0,JSON.stringify(t),s);return dt(r)}async function Le(e,o,t,s){const n=await(await X(o,P.GENERATE_CONTENT,e,!1,JSON.stringify(t),s)).json();return{response:ie(n)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function De(e){if(e!=null){if(typeof e=="string")return{role:"system",parts:[{text:e}]};if(e.text)return{role:"system",parts:[e]};if(e.parts)return e.role?e:{role:"system",parts:e.parts}}}function Q(e){let o=[];if(typeof e=="string")o=[{text:e}];else for(const t of e)typeof t=="string"?o.push({text:t}):o.push(t);return mt(o)}function mt(e){const o={role:"user",parts:[]},t={role:"function",parts:[]};let s=!1,r=!1;for(const n of e)"functionResponse"in n?(t.parts.push(n),r=!0):(o.parts.push(n),s=!0);if(s&&r)throw new T("Within a single message, FunctionResponse cannot be mixed with other type of part in the request for sending chat message.");if(!s&&!r)throw new T("No content is provided for sending chat message.");return s?o:t}function gt(e,o){var t;let s={model:o?.model,generationConfig:o?.generationConfig,safetySettings:o?.safetySettings,tools:o?.tools,toolConfig:o?.toolConfig,systemInstruction:o?.systemInstruction,cachedContent:(t=o?.cachedContent)===null||t===void 0?void 0:t.name,contents:[]};const r=e.generateContentRequest!=null;if(e.contents){if(r)throw new B("CountTokensRequest must have one of contents or generateContentRequest, not both.");s.contents=e.contents}else if(r)s=Object.assign(Object.assign({},s),e.generateContentRequest);else{const n=Q(e);s.contents=[n]}return{generateContentRequest:s}}function Ie(e){let o;return e.contents?o=e:o={contents:[Q(e)]},e.systemInstruction&&(o.systemInstruction=De(e.systemInstruction)),o}function vt(e){return typeof e=="string"||Array.isArray(e)?{content:Q(e)}:e}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ke=["text","inlineData","functionCall","functionResponse","executableCode","codeExecutionResult"],xt={user:["text","inlineData"],function:["functionResponse"],model:["text","functionCall","executableCode","codeExecutionResult"],system:["text"]};function yt(e){let o=!1;for(const t of e){const{role:s,parts:r}=t;if(!o&&s!=="user")throw new T(`First content should be with role 'user', got ${s}`);if(!ge.includes(s))throw new T(`Each item should include role field. Got ${s} but valid roles are: ${JSON.stringify(ge)}`);if(!Array.isArray(r))throw new T("Content should have 'parts' property with an array of Parts");if(r.length===0)throw new T("Each Content should have at least one part");const n={text:0,inlineData:0,functionCall:0,functionResponse:0,fileData:0,executableCode:0,codeExecutionResult:0};for(const u of r)for(const p of ke)p in u&&(n[p]+=1);const i=xt[s];for(const u of ke)if(!i.includes(u)&&n[u]>0)throw new T(`Content with role '${s}' can't contain '${u}' part`);o=!0}}function Oe(e){var o;if(e.candidates===void 0||e.candidates.length===0)return!1;const t=(o=e.candidates[0])===null||o===void 0?void 0:o.content;if(t===void 0||t.parts===void 0||t.parts.length===0)return!1;for(const s of t.parts)if(s===void 0||Object.keys(s).length===0||s.text!==void 0&&s.text==="")return!1;return!0}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Re="SILENT_ERROR";class Et{constructor(o,t,s,r={}){this.model=t,this.params=s,this._requestOptions=r,this._history=[],this._sendPromise=Promise.resolve(),this._apiKey=o,s?.history&&(yt(s.history),this._history=s.history)}async getHistory(){return await this._sendPromise,this._history}async sendMessage(o,t={}){var s,r,n,i,u,p;await this._sendPromise;const R=Q(o),_={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(r=this.params)===null||r===void 0?void 0:r.generationConfig,tools:(n=this.params)===null||n===void 0?void 0:n.tools,toolConfig:(i=this.params)===null||i===void 0?void 0:i.toolConfig,systemInstruction:(u=this.params)===null||u===void 0?void 0:u.systemInstruction,cachedContent:(p=this.params)===null||p===void 0?void 0:p.cachedContent,contents:[...this._history,R]},b=Object.assign(Object.assign({},this._requestOptions),t);let g;return this._sendPromise=this._sendPromise.then(()=>Le(this._apiKey,this.model,_,b)).then(h=>{var y;if(Oe(h.response)){this._history.push(R);const M=Object.assign({parts:[],role:"model"},(y=h.response.candidates)===null||y===void 0?void 0:y[0].content);this._history.push(M)}else{const M=U(h.response);M&&console.warn(`sendMessage() was unsuccessful. ${M}. Inspect response object for details.`)}g=h}).catch(h=>{throw this._sendPromise=Promise.resolve(),h}),await this._sendPromise,g}async sendMessageStream(o,t={}){var s,r,n,i,u,p;await this._sendPromise;const R=Q(o),_={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(r=this.params)===null||r===void 0?void 0:r.generationConfig,tools:(n=this.params)===null||n===void 0?void 0:n.tools,toolConfig:(i=this.params)===null||i===void 0?void 0:i.toolConfig,systemInstruction:(u=this.params)===null||u===void 0?void 0:u.systemInstruction,cachedContent:(p=this.params)===null||p===void 0?void 0:p.cachedContent,contents:[...this._history,R]},b=Object.assign(Object.assign({},this._requestOptions),t),g=Ge(this._apiKey,this.model,_,b);return this._sendPromise=this._sendPromise.then(()=>g).catch(h=>{throw new Error(Re)}).then(h=>h.response).then(h=>{if(Oe(h)){this._history.push(R);const y=Object.assign({},h.candidates[0].content);y.role||(y.role="model"),this._history.push(y)}else{const y=U(h);y&&console.warn(`sendMessageStream() was unsuccessful. ${y}. Inspect response object for details.`)}}).catch(h=>{h.message!==Re&&console.error(h)}),g}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function bt(e,o,t,s){return(await X(o,P.COUNT_TOKENS,e,!1,JSON.stringify(t),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _t(e,o,t,s){return(await X(o,P.EMBED_CONTENT,e,!1,JSON.stringify(t),s)).json()}async function wt(e,o,t,s){const r=t.requests.map(i=>Object.assign(Object.assign({},i),{model:o}));return(await X(o,P.BATCH_EMBED_CONTENTS,e,!1,JSON.stringify({requests:r}),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Se{constructor(o,t,s={}){this.apiKey=o,this._requestOptions=s,t.model.includes("/")?this.model=t.model:this.model=`models/${t.model}`,this.generationConfig=t.generationConfig||{},this.safetySettings=t.safetySettings||[],this.tools=t.tools,this.toolConfig=t.toolConfig,this.systemInstruction=De(t.systemInstruction),this.cachedContent=t.cachedContent}async generateContent(o,t={}){var s;const r=Ie(o),n=Object.assign(Object.assign({},this._requestOptions),t);return Le(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},r),n)}async generateContentStream(o,t={}){var s;const r=Ie(o),n=Object.assign(Object.assign({},this._requestOptions),t);return Ge(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},r),n)}startChat(o){var t;return new Et(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(t=this.cachedContent)===null||t===void 0?void 0:t.name},o),this._requestOptions)}async countTokens(o,t={}){const s=gt(o,{model:this.model,generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:this.cachedContent}),r=Object.assign(Object.assign({},this._requestOptions),t);return bt(this.apiKey,this.model,s,r)}async embedContent(o,t={}){const s=vt(o),r=Object.assign(Object.assign({},this._requestOptions),t);return _t(this.apiKey,this.model,s,r)}async batchEmbedContents(o,t={}){const s=Object.assign(Object.assign({},this._requestOptions),t);return wt(this.apiKey,this.model,o,s)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ct{constructor(o){this.apiKey=o}getGenerativeModel(o,t){if(!o.model)throw new T("Must provide a model name. Example: genai.getGenerativeModel({ model: 'my-model-name' })");return new Se(this.apiKey,o,t)}getGenerativeModelFromCachedContent(o,t,s){if(!o.name)throw new B("Cached content must contain a `name` field.");if(!o.model)throw new B("Cached content must contain a `model` field.");const r=["model","systemInstruction"];for(const i of r)if(t?.[i]&&o[i]&&t?.[i]!==o[i]){if(i==="model"){const u=t.model.startsWith("models/")?t.model.replace("models/",""):t.model,p=o.model.startsWith("models/")?o.model.replace("models/",""):o.model;if(u===p)continue}throw new B(`Different value for "${i}" specified in modelParams (${t[i]}) and cachedContent (${o[i]})`)}const n=Object.assign(Object.assign({},t),{model:o.model,tools:o.tools,toolConfig:o.toolConfig,systemInstruction:o.systemInstruction,cachedContent:o});return new Se(this.apiKey,n,s)}}const At=()=>{const e=Be(),o=Ne(),t=Ue(),s=G(!1),r=G(null);let n=null;e.public.googleAiApiKey&&(n=new Ct(e.public.googleAiApiKey));const i=async()=>{try{if(!t.value)return console.log("[useGemini] No user logged in"),!1;console.log("[useGemini] Checking Pro access for user:",t.value.id);const{data:v,error:f}=await o.from("users").select("subscription_type, trial_ends_at").eq("id",t.value.id).single();f&&console.error("[useGemini] Error fetching user data:",f);const{data:x,error:m}=await o.from("subscriptions").select("plan_type, status").eq("user_id",t.value.id).eq("status","active").maybeSingle();m&&m.code!=="PGRST116"&&console.error("[useGemini] Error fetching subscription:",m);const E=v?.subscription_type==="pro",C=v?.trial_ends_at&&new Date(v.trial_ends_at)>new Date,A=x?.plan_type==="pro"&&x?.status==="active",I=E||C||A;return console.log("[useGemini] Access check:",{userId:t.value.id,subscription_type:v?.subscription_type,trial_ends_at:v?.trial_ends_at,active_subscription:x?.plan_type,isProUserTable:E,hasActiveTrial:C,hasActiveProSub:A,FINAL_ACCESS:I}),I||(console.warn("[useGemini] ⚠️ DEBUG MODE: Bypassing Pro check - REMOVE IN PRODUCTION"),!0)}catch(v){return console.error("[useGemini] Error checking Pro access:",v),console.warn("[useGemini] ⚠️ DEBUG MODE: Bypassing due to error - REMOVE IN PRODUCTION"),!0}},u=()=>{const v=`ai_requests_${t.value?.id||"anon"}`,f=Date.now(),x=3600*1e3,m=localStorage.getItem(v);let E=m?JSON.parse(m):{count:0,resetAt:f+x};if(f>E.resetAt&&(E={count:0,resetAt:f+x}),E.count>=20){const C=Math.ceil((E.resetAt-f)/6e4);return r.value=`Limite de 20 requisições por hora atingido. Aguarde ${C} minutos.`,!1}return E.count++,localStorage.setItem(v,JSON.stringify(E)),!0},p=async(v,f={})=>{s.value=!0,r.value=null;try{if(!n)throw new Error("Google AI não está configurado. Verifique a API key.");if(!await i())throw new Error("Recursos de IA disponíveis apenas no plano Pro. Faça upgrade para desbloquear.");if(!u())throw new Error(r.value||"Limite de requisições atingido");const x=n.getGenerativeModel({model:f.model||"gemini-2.0-flash-exp",generationConfig:{temperature:f.temperature||.7,maxOutputTokens:f.maxTokens||2048},systemInstruction:f.systemInstruction});console.log("[useGemini] Generating content with prompt length:",v.length);const C=(await x.generateContent(v)).response.text();return console.log("[useGemini] Response received, length:",C.length),C}catch(x){throw console.error("[useGemini] Error generating content:",x),r.value=x.message||"Erro ao gerar conteúdo",x}finally{s.value=!1}},R=v=>{console.log("[useGemini] Starting JSON parsing...");let f=v.trim();f=f.replace(/```json\s*/gi,"").replace(/```\s*/g,"").trim();const x=f.match(/[\[{][\s\S]*[\]}]/);if(!x)throw console.error("[useGemini] No JSON found in response:",v.substring(0,200)),new Error("Resposta da IA não contém JSON válido");let m=x[0];for(console.log("[useGemini] Extracted JSON length:",m.length),m=m.replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F]/g,""),m=m.replace(/\u2028/g,"\\n").replace(/\u2029/g,"\\n"),m=m.replace(/([^\\])\r?\n/g,"$1 ");m.includes("\\\\\\\\");)m=m.replace(/\\\\\\\\/g,"\\\\");m=m.replace(/,\s*([}\]])/g,"$1");try{const E=JSON.parse(m);return console.log("[useGemini] ✓ JSON parsed successfully"),E}catch(E){console.warn("[useGemini] First parse attempt failed:",E.message);const C=E.message.match(/position (\d+)/)?.[1];if(C){const A=parseInt(C),I=Math.max(0,A-80),j=Math.min(m.length,A+80),N=m.substring(I,j),L=" ".repeat(Math.min(80,A-I))+"^";console.error(`[useGemini] Error context:
`,N,`
`,L)}try{console.log("[useGemini] Attempting space normalization...");let A=m.replace(/\t/g," ").replace(/\s{2,}/g," ").replace(/,\s*}/g,"}").replace(/,\s*]/g,"]");const I=JSON.parse(A);return console.log("[useGemini] ✓ Parsed with space normalization"),I}catch(A){console.warn("[useGemini] Second parse attempt failed:",A.message);try{console.log("[useGemini] Attempting permissive parsing...");let I=m,j=!1,N=!1,L="";for(let F=0;F<I.length;F++){const q=I[F],le=F>0?I[F-1]:"";q==='"'&&!N?(j=!j,L+=q):j&&q==="\\"&&!N?(N=!0,L+=q):(N&&(N=!1),L+=q)}const oe=JSON.parse(L);return console.log("[useGemini] ✓ Parsed with permissive mode"),oe}catch{throw console.error("[useGemini] All parse attempts failed"),console.error("[useGemini] Original response (first 500 chars):",v.substring(0,500)),console.error("[useGemini] Processed JSON (first 500 chars):",m.substring(0,500)),new Error("Não foi possível processar a resposta da IA. Tente gerar novamente com um conteúdo diferente.")}}}},_=async(v,f=5,x="medium",m="Conteúdo")=>{const E={easy:"fácil",medium:"médio",hard:"difícil"},C=`Você é um professor experiente criando exercícios de múltipla escolha.

Baseado no seguinte conteúdo sobre "${m}":
${v.substring(0,3e3)}

Crie EXATAMENTE ${f} questões de múltipla escolha de nível ${E[x]||x}.

RETORNE APENAS O JSON ABAIXO (sem texto antes ou depois, sem markdown):

{
  "exercises": [
    {
      "question": "Pergunta completa aqui",
      "options": {
        "A": "Primeira opcao",
        "B": "Segunda opcao",
        "C": "Terceira opcao",
        "D": "Quarta opcao"
      },
      "correct_answer": "A",
      "explanation": "Explicacao da resposta correta"
    }
  ]
}

REGRAS DE FORMATAÇÃO:
1. Cada questão deve ter exatamente 4 opções (A, B, C, D)
2. Apenas uma resposta correta por questão
3. Para aspas dentro do texto, use aspas simples (')
   Exemplo: "A formula de Newton e F = m × a"
4. Para fórmulas matemáticas, use Unicode ou texto simples:
   ✓ "E = mc²" ou "E = mc^2"
   ✓ "π × r²" ou "pi × r^2"
   ✓ "√2" ou "raiz(2)"
5. Mantenha cada valor em uma única linha (sem quebras 
)
6. Símbolos permitidos: ±, ×, ÷, ≠, ≤, ≥, °, ², ³, α, β, π, Σ, √, etc
7. Acentuação normal permitida: á, é, í, ó, ú, ã, õ, ç
8. Questões devem ser relevantes e explicações claras

IMPORTANTE: Retorne JSON válido que funcione com JSON.parse()`;try{const A=await p(C,{temperature:.7,model:"gemini-2.0-flash-exp"});console.log("[useGemini] Raw response length:",A.length);const I=R(A),j=I.exercises||I;if(!Array.isArray(j))throw new Error("Formato de exercícios inválido");return j.map((N,L)=>{if(!N.question)throw new Error(`Exercício ${L+1} sem pergunta`);if(!N.options)throw new Error(`Exercício ${L+1} sem opções`);if(!N.correct_answer)throw new Error(`Exercício ${L+1} sem resposta`);return{question:N.question,options:N.options,correct_answer:N.correct_answer,explanation:N.explanation||""}})}catch(A){throw console.error("[useGemini] Error generating exercises:",A),A}},b=async(v,f="concise")=>{const m=`Crie um ${{detailed:"resumo detalhado com explicações completas",concise:"resumo conciso com pontos principais",topics:"lista de tópicos principais em bullet points"}[f]} do seguinte conteúdo:

${v.substring(0,5e3)}

Formato: Markdown bem estruturado em português brasileiro.`;return await p(m,{temperature:.5})},g=async(v,f=10,x="Conteúdo")=>{const m=`Baseado no conteúdo sobre "${x}", crie ${f} flashcards.

Conteúdo:
${v.substring(0,3e3)}

Retorne APENAS um JSON válido:
{
  "flashcards": [
    {
      "front": "Pergunta ou conceito",
      "back": "Resposta ou explicação",
      "category": "Categoria do card"
    }
  ]
}`;try{const E=await p(m,{temperature:.7}),C=R(E),A=C.flashcards||C;if(!Array.isArray(A))throw new Error("Formato inválido");return A.map(I=>({front:I.front||"",back:I.back||"",category:I.category||x}))}catch(E){throw console.error("[useGemini] Error generating flashcards:",E),E}},h=async(v,f)=>{const x=v.map(C=>`${C.role==="user"?"Aluno":"Tutor"}: ${C.content}`).join(`

`);return await p(x,{systemInstruction:f||"Você é um tutor educacional brasileiro especializado em concursos e vestibulares. Responda de forma clara, didática e em português do Brasil. Use exemplos práticos e seja encorajador.",temperature:.7,maxTokens:1024})},y=async(v,f)=>await p(v,{systemInstruction:f||"Você é um tutor educacional brasileiro especializado em concursos e vestibulares. Responda de forma clara, didática e em português do Brasil. Use exemplos práticos e seja encorajador.",temperature:.7,maxTokens:1024}),M=async(v,f="Mapa Mental")=>{const x=`Crie um mapa mental sobre "${f}" baseado no conteúdo:

${v.substring(0,3e3)}

Retorne APENAS um JSON válido com a estrutura hierárquica:
{
  "title": "${f}",
  "nodes": [
    {
      "id": "1",
      "text": "Conceito Principal",
      "children": [
        {
          "id": "1.1",
          "text": "Subconceito",
          "children": []
        }
      ]
    }
  ]
}`;try{const m=await p(x,{temperature:.6});return R(m)}catch(m){throw console.error("[useGemini] Error generating mind map:",m),m}},H=async v=>{const f=`Explique de forma clara e didática o seguinte trecho:

"${v}"

Forneça:
1. Explicação do conceito
2. Exemplos práticos
3. Dicas para memorização

Use linguagem acessível em português brasileiro.`;return await p(f,{temperature:.6,maxTokens:1024})};return{loading:ce(s),error:ce(r),hasProAccess:i,generateContent:p,generateExercises:_,generateSummary:b,generateFlashcards:g,chat:h,sendMessage:y,generateMindMap:M,explainSelection:H}},It={class:"bg-dark-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden border border-dark-700"},kt={class:"bg-dark-800 border-b border-dark-700 px-6 py-4 flex items-center justify-between"},Ot={class:"flex items-center space-x-3"},Rt={class:"text-sm text-gray-400"},St={key:0,class:"p-6 space-y-6 bg-dark-900"},Nt={class:"flex items-center space-x-4"},Tt={class:"text-2xl font-bold text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors w-12 text-center"},Mt={class:"grid grid-cols-3 gap-3"},Gt=["onClick"],Lt={class:"text-sm font-semibold text-white"},Dt=["disabled"],jt={key:0,class:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24"},$t={key:1,class:"w-6 h-6 animate-spin",fill:"none",viewBox:"0 0 24 24"},Ut={key:0,class:"bg-red-500/10 border border-red-500/30 rounded-claude-md p-4 flex items-start space-x-3"},Bt={class:"text-sm text-red-400"},Ft={key:1,class:"flex-1 overflow-y-auto p-6 bg-dark-900"},qt={class:"max-w-2xl mx-auto space-y-6"},Pt={class:"text-center mb-8"},Ht={class:"w-32 h-32 mx-auto mb-6 relative"},Kt={class:"transform -rotate-90 w-32 h-32"},Vt=["stroke-dashoffset"],Yt={class:"absolute inset-0 flex items-center justify-center"},Jt={class:"text-3xl font-bold text-white"},zt={class:"text-2xl font-bold text-white mb-2"},Qt={class:"text-gray-400"},Xt={class:"grid grid-cols-3 gap-4 mb-6"},Wt={class:"bg-dark-700/30 border border-dark-600 rounded-claude-lg p-4 text-center"},Zt={class:"text-2xl font-bold text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors mb-1"},eo={class:"bg-dark-700/30 border border-dark-600 rounded-claude-lg p-4 text-center"},to={class:"text-2xl font-bold text-red-400 mb-1"},oo={class:"bg-dark-700/30 border border-dark-600 rounded-claude-lg p-4 text-center"},so={class:"text-2xl font-bold text-yellow-400 mb-1"},ro={class:"bg-dark-700/30 border border-dark-600 rounded-claude-lg p-6"},no={class:"space-y-2 max-h-60 overflow-y-auto"},ao=["onClick"],io={class:"text-sm text-gray-300"},lo={key:0,class:"w-5 h-5 text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors",fill:"currentColor",viewBox:"0 0 20 20"},co={key:1,class:"w-5 h-5 text-red-400",fill:"currentColor",viewBox:"0 0 20 20"},uo={class:"bg-dark-700/30 border border-dark-600 rounded-claude-lg p-6"},fo=["disabled"],ho={key:2,class:"flex-1 overflow-y-auto p-6 bg-dark-900"},po={key:0,class:"space-y-6"},mo={class:"bg-dark-700/30 border border-dark-600 rounded-claude-lg p-6"},go={class:"flex items-start justify-between mb-4"},vo={class:"text-lg font-semibold text-white"},xo={class:"px-3 py-1 bg-claude-primary/20 dark:bg-primary-500/20 text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors text-xs font-semibold rounded-full"},yo={class:"text-gray-300 leading-relaxed"},Eo={class:"space-y-3"},bo=["onClick","disabled"],_o={class:"flex items-center space-x-3"},wo={class:"flex-1 text-gray-300"},Co={key:0,class:"w-6 h-6 text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors",fill:"currentColor",viewBox:"0 0 20 20"},Ao={key:1,class:"w-6 h-6 text-red-400",fill:"currentColor",viewBox:"0 0 20 20"},Io={key:0,class:"bg-gray-700/50 border border-gray-600 rounded-claude-lg p-5"},ko={class:"flex items-start space-x-3"},Oo={class:"text-gray-300 leading-relaxed"},Ro={key:3,class:"border-t border-dark-700 bg-dark-800 px-6 py-4"},So={class:"flex items-center justify-between"},No=["disabled"],To={class:"text-sm text-gray-400"},Mo={class:"font-bold text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors"},Go=Fe({__name:"AIExercisesModal",props:{isOpen:{type:Boolean},content:{},chapterTitle:{},subjectId:{}},emits:["close"],setup(e,{emit:o}){const t=e,s=o,{generateExercises:r}=At(),n=G({quantity:5,difficulty:"medium"}),i=[{value:"easy",label:"Fácil"},{value:"medium",label:"Médio"},{value:"hard",label:"Difícil"}],u=G(!1),p=G(""),R=G(!1),_=G([]),b=G(0),g=G(null),h=G(!1),y=G({}),M=G(!1),H=G(!1),v=G(!1),f=W(()=>_.value[b.value]),x=W(()=>Object.values(y.value).filter(c=>c.correct).length),m=W(()=>Object.keys(y.value).length),E=W(()=>_.value.length>0?x.value/_.value.length*100:0),C=2*Math.PI*56,A=async()=>{u.value=!0,p.value="";try{if(!t.content||t.content.trim().length<20)throw new Error("O conteúdo é muito curto para gerar exercícios. É necessário pelo menos 20 caracteres de texto.");const c=await r(t.content,n.value.quantity,n.value.difficulty,t.chapterTitle);if(!c||!Array.isArray(c)||c.length===0)throw new Error("Nenhum exercício foi gerado. Tente novamente com um conteúdo diferente.");_.value=c,R.value=!0}catch(c){console.error("Erro ao gerar exercícios:",c),c.message?p.value=c.message:c.statusCode===429||c.status===429?p.value="Você atingiu o limite de requisições de IA. Aguarde alguns minutos e tente novamente.":c.statusCode===401||c.status===401?p.value="Você precisa estar logado para usar recursos de IA.":c.statusCode===403||c.status===403?p.value="Recursos de IA disponíveis apenas no plano Pro. Faça upgrade para desbloquear.":p.value="Erro ao gerar exercícios. Verifique sua conexão e tente novamente."}finally{u.value=!1}},I=c=>{h.value||(g.value=c,h.value=!0,y.value[b.value]={selected:c,correct:c===f.value.correct_answer})},j=c=>h.value?c===f.value.correct_answer?"border-claude-primary bg-primary-500/10":c===g.value&&c!==f.value.correct_answer?"border-red-500 bg-red-500/10":"border-dark-600 opacity-60":"border-dark-600 hover:border-claude-primary hover:bg-dark-700/50",N=c=>h.value?c===f.value.correct_answer?"bg-primary-500 text-white":c===g.value&&c!==f.value.correct_answer?"bg-red-500 text-white":"bg-dark-600 text-gray-300":"bg-dark-600 text-gray-300",L=()=>{b.value<_.value.length-1&&(b.value++,y.value[b.value]?(g.value=y.value[b.value].selected,h.value=!0):(g.value=null,h.value=!1))},oe=()=>{b.value>0&&(b.value--,y.value[b.value]?(g.value=y.value[b.value].selected,h.value=!0):(g.value=null,h.value=!1))},F=()=>{M.value=!0},q=()=>{const c=E.value;return c===100?"🎉 Perfeito! Parabéns!":c>=90?"🌟 Excelente trabalho!":c>=70?"👏 Muito bom!":c>=50?"👍 Bom esforço!":"💪 Continue estudando!"},le=c=>{M.value=!1,b.value=c,y.value[c]?(g.value=y.value[c].selected,h.value=!0):(g.value=null,h.value=!1)},je=()=>{M.value=!1,R.value=!1,_.value=[],b.value=0,g.value=null,h.value=!1,y.value={},v.value=!1},$e=async()=>{H.value=!0,console.log("[AIExercisesModal] 🚀 Iniciando saveToReports...");try{const c=Ne();let l=t.subjectId||null;if(l)console.log("[AIExercisesModal] ✅ Usando subject_id da prop:",l);else if(t.chapterTitle){console.log("[AIExercisesModal] 🔍 subject_id não fornecido, tentando buscar por chapterTitle:",t.chapterTitle);const{data:$,error:Y}=await c.from("subjects").select("id, name").ilike("name",`%${t.chapterTitle}%`).limit(1);Y?console.error("[AIExercisesModal] ❌ Erro ao buscar subject:",Y):$&&$.length>0?(l=$[0].id,console.log("[AIExercisesModal] ✅ Subject encontrado por nome:",l,"- Nome:",$[0].name)):console.warn("[AIExercisesModal] ⚠️ Nenhum subject encontrado com nome similar a:",t.chapterTitle)}else console.log("[AIExercisesModal] ⚠️ Nenhum subjectId ou chapterTitle fornecido, subject_id será NULL");const D=_.value.map(($,Y)=>({question:$.question,options:$.options,correct_answer:$.correct_answer,explanation:$.explanation,selected_answer:y.value[Y]?.selected||null,is_correct:y.value[Y]?.correct||!1})),S={subject_id:l,title:t.chapterTitle?`Exercícios - ${t.chapterTitle}`:"Exercícios IA",total_questions:_.value.length,correct_answers:x.value,score_percentage:E.value,questions_data:D};console.log("[AIExercisesModal] 📦 Payload completo:",JSON.stringify(S,null,2)),console.log("[AIExercisesModal] 🔑 Subject ID no payload:",l||"NULL"),console.log("[AIExercisesModal] 📡 Chamando /api/exercises/save...");const re=await $fetch("/api/exercises/save",{method:"POST",body:S});console.log("[AIExercisesModal] ✅ Resposta da API:",re),v.value=!0,console.log("✅ Exercícios salvos com sucesso nos relatórios!")}catch(c){console.error("[AIExercisesModal] ❌ ERRO COMPLETO:",c),console.error("[AIExercisesModal] ❌ Status:",c?.statusCode),console.error("[AIExercisesModal] ❌ Message:",c?.message),console.error("[AIExercisesModal] ❌ Data:",c?.data),alert(`Erro ao salvar: ${c?.message||c}`)}finally{H.value=!1,console.log("[AIExercisesModal] 🏁 saveToReports finalizado")}},se=()=>{s("close"),setTimeout(()=>{R.value=!1,_.value=[],b.value=0,g.value=null,h.value=!1,y.value={},n.value={quantity:5,difficulty:"medium"},M.value=!1,v.value=!1},300)};return qe(()=>t.isOpen,async c=>{c&&t.content&&!R.value&&!u.value&&(console.log("[AIExercisesModal] 🚀 Modal opened with content, auto-generating exercises..."),console.log("[AIExercisesModal] Content length:",t.content.length),console.log("[AIExercisesModal] Chapter:",t.chapterTitle),await A())}),(c,l)=>(w(),Pe(He,{to:"body"},[de(fe,{name:"modal"},{default:ue(()=>[e.isOpen?(w(),k("div",{key:0,class:"fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black bg-opacity-50 backdrop-blur-sm",onClick:Ye(se,["self"])},[a("div",It,[a("div",kt,[a("div",Ot,[l[2]||(l[2]=a("div",{class:"w-10 h-10 bg-claude-primary/20 dark:bg-primary-500/20 rounded-claude-md flex items-center justify-center"},[a("svg",{class:"w-6 h-6 text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24"},[a("path",{"stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"2",d:"M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"})])],-1)),a("div",null,[l[1]||(l[1]=a("h2",{class:"text-xl font-bold text-white"},"Exercícios Gerados por IA",-1)),a("p",Rt,O(d(_).length>0?`${d(b)+1} de ${d(_).length}`:"Configure seus exercícios"),1)])]),a("button",{onClick:se,class:"text-white hover:bg-white hover:bg-opacity-20 rounded-claude-md p-2 transition-colors"},[...l[3]||(l[3]=[a("svg",{class:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24"},[a("path",{"stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"2",d:"M6 18L18 6M6 6l12 12"})],-1)])])]),d(R)?d(M)?(w(),k("div",Ft,[a("div",qt,[a("div",Pt,[a("div",Ht,[(w(),k("svg",Kt,[l[9]||(l[9]=a("circle",{cx:"64",cy:"64",r:"56",stroke:"currentColor","stroke-width":"8",fill:"none",class:"text-dark-600"},null,-1)),a("circle",{cx:"64",cy:"64",r:"56",stroke:"currentColor","stroke-width":"8",fill:"none","stroke-dasharray":C,"stroke-dashoffset":C-d(E)/100*C,class:"text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors transition-all duration-1000"},null,8,Vt)])),a("div",Yt,[a("span",Jt,O(d(E).toFixed(0))+"%",1)])]),a("h3",zt,O(q()),1),a("p",Qt,O(d(x))+" acertos de "+O(d(_).length)+" questões",1)]),a("div",Xt,[a("div",Wt,[a("div",Zt,O(d(x)),1),l[10]||(l[10]=a("div",{class:"text-xs text-gray-400"},"Acertos",-1))]),a("div",eo,[a("div",to,O(d(_).length-d(x)),1),l[11]||(l[11]=a("div",{class:"text-xs text-gray-400"},"Erros",-1))]),a("div",oo,[a("div",so,O(d(E).toFixed(1)),1),l[12]||(l[12]=a("div",{class:"text-xs text-gray-400"},"Nota",-1))])]),a("div",ro,[l[15]||(l[15]=a("h4",{class:"font-semibold text-white mb-4 flex items-center gap-2"},[a("svg",{class:"w-5 h-5 text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24"},[a("path",{"stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"2",d:"M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"})]),ee(" Revisão das Questões ")],-1)),a("div",no,[(w(!0),k(ne,null,ae(d(_),(D,S)=>(w(),k("button",{key:S,onClick:re=>le(S),class:Z(["w-full flex items-center justify-between p-3 rounded-claude-md border transition-colors",d(y)[S]?.correct?"border-claude-primary dark:border-primary-500/30 bg-primary-500/5 hover:bg-primary-500/10":"border-red-500/30 bg-red-500/5 hover:bg-red-500/10"])},[a("span",io,"Questão "+O(S+1),1),d(y)[S]?.correct?(w(),k("svg",lo,[...l[13]||(l[13]=[a("path",{"fill-rule":"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z","clip-rule":"evenodd"},null,-1)])])):(w(),k("svg",co,[...l[14]||(l[14]=[a("path",{"fill-rule":"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z","clip-rule":"evenodd"},null,-1)])]))],10,ao))),128))])]),a("div",uo,[l[16]||(l[16]=a("h4",{class:"font-semibold text-white mb-3 flex items-center gap-2"},[a("svg",{class:"w-5 h-5 text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24"},[a("path",{"stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"2",d:"M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"})]),ee(" Salvar nos Relatórios ")],-1)),l[17]||(l[17]=a("p",{class:"text-sm text-gray-400 mb-4"},"Deseja adicionar este resultado aos seus relatórios de estudo?",-1)),a("button",{onClick:$e,disabled:d(H),class:"w-full px-4 py-3 bg-claude-primary dark:bg-gradient-to-r dark:from-primary-500 dark:to-primary-600 text-white hover:bg-claude-hover dark:hover:from-primary-600 dark:hover:to-primary-700 transition-all duration-200 shadow-claude-sm hover:shadow-claude-md hover:from-claude-hover hover:to-primary-700 dark:hover:from-primary-600 dark:hover:to-primary-700 text-white rounded-claude-md transition-colors font-medium disabled:opacity-50"},O(d(H)?"Salvando...":d(v)?"✓ Salvo nos Relatórios":"Salvar nos Relatórios"),9,fo)]),a("div",{class:"flex gap-3"},[a("button",{onClick:je,class:"flex-1 px-4 py-3 border border-dark-600 hover:bg-dark-700 text-white rounded-claude-md transition-colors font-medium"}," Fazer Novamente "),a("button",{onClick:se,class:"flex-1 px-4 py-3 bg-claude-primary dark:bg-gradient-to-r dark:from-primary-500 dark:to-primary-600 text-white hover:bg-claude-hover dark:hover:from-primary-600 dark:hover:to-primary-700 transition-all duration-200 shadow-claude-sm hover:shadow-claude-md hover:from-claude-hover hover:to-primary-700 dark:hover:from-primary-600 dark:hover:to-primary-700 text-white rounded-claude-md transition-colors font-medium"}," Fechar ")])])])):(w(),k("div",ho,[d(f)?(w(),k("div",po,[a("div",mo,[a("div",go,[a("h3",vo,"Questão "+O(d(b)+1),1),a("span",xo,O(d(n).difficulty),1)]),a("p",yo,O(d(f).question),1)]),a("div",Eo,[(w(!0),k(ne,null,ae(d(f).options,(D,S)=>(w(),k("button",{key:S,onClick:re=>I(S),disabled:d(h),class:Z(["w-full text-left px-5 py-4 rounded-claude-lg border-2 transition-all",j(S)])},[a("div",_o,[a("span",{class:Z(["flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm",N(S)])},O(S),3),a("span",wo,O(D),1),d(h)&&S===d(f).correct_answer?(w(),k("svg",Co,[...l[18]||(l[18]=[a("path",{"fill-rule":"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z","clip-rule":"evenodd"},null,-1)])])):d(h)&&S===d(g)&&S!==d(f).correct_answer?(w(),k("svg",Ao,[...l[19]||(l[19]=[a("path",{"fill-rule":"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z","clip-rule":"evenodd"},null,-1)])])):K("",!0)])],10,bo))),128))]),de(fe,{name:"slide-down"},{default:ue(()=>[d(h)&&d(f).explanation?(w(),k("div",Io,[a("div",ko,[l[21]||(l[21]=a("svg",{class:"w-6 h-6 text-claude-text-link dark:text-primary-400 hover:text-claude-hover dark:hover:text-primary-300 transition-colors flex-shrink-0 mt-0.5",fill:"currentColor",viewBox:"0 0 20 20"},[a("path",{"fill-rule":"evenodd",d:"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z","clip-rule":"evenodd"})],-1)),a("div",null,[l[20]||(l[20]=a("h4",{class:"font-semibold text-white mb-2"},"Explicação",-1)),a("p",Oo,O(d(f).explanation),1)])])])):K("",!0)]),_:1})])):K("",!0)])):(w(),k("div",St,[a("div",null,[l[4]||(l[4]=a("label",{class:"block text-sm font-semibold text-white mb-2"},"Quantidade de questões",-1)),a("div",Nt,[Ke(a("input",{"onUpdate:modelValue":l[0]||(l[0]=D=>d(n).quantity=D),type:"range",min:"1",max:"20",class:"flex-1 h-2 bg-dark-600 rounded-claude-md appearance-none cursor-pointer"},null,512),[[Ve,d(n).quantity,void 0,{number:!0}]]),a("span",Tt,O(d(n).quantity),1)])]),a("div",null,[l[5]||(l[5]=a("label",{class:"block text-sm font-semibold text-white mb-3"},"Nível de dificuldade",-1)),a("div",Mt,[(w(),k(ne,null,ae(i,D=>a("button",{key:D.value,onClick:S=>d(n).difficulty=D.value,class:Z(["px-4 py-3 rounded-claude-lg border-2 transition-all",d(n).difficulty===D.value?"border-claude-primary bg-dark-700/30 shadow-md":"border-dark-600 hover:border-claude-primary dark:hover:border-primary-500 dark:border-primary-500/50"])},[a("div",Lt,O(D.label),1)],10,Gt)),64))])]),a("button",{onClick:A,disabled:d(u),class:"w-full px-6 py-4 bg-claude-primary dark:bg-gradient-to-r dark:from-primary-500 dark:to-primary-600 text-white hover:bg-claude-hover dark:hover:from-primary-600 dark:hover:to-primary-700 transition-all duration-200 shadow-claude-sm hover:shadow-claude-md hover:from-claude-hover hover:to-primary-700 dark:hover:from-primary-600 dark:hover:to-primary-700 text-white rounded-claude-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed font-semibold text-lg flex items-center justify-center space-x-2"},[d(u)?(w(),k("svg",$t,[...l[7]||(l[7]=[a("circle",{class:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor","stroke-width":"4"},null,-1),a("path",{class:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"},null,-1)])])):(w(),k("svg",jt,[...l[6]||(l[6]=[a("path",{"stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"2",d:"M13 10V3L4 14h7v7l9-11h-7z"},null,-1)])])),a("span",null,O(d(u)?"Gerando exercícios...":"Gerar Exercícios"),1)],8,Dt),d(p)?(w(),k("div",Ut,[l[8]||(l[8]=a("svg",{class:"w-5 h-5 text-red-400 flex-shrink-0 mt-0.5",fill:"currentColor",viewBox:"0 0 20 20"},[a("path",{"fill-rule":"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z","clip-rule":"evenodd"})],-1)),a("p",Bt,O(d(p)),1)])):K("",!0)])),d(R)?(w(),k("div",Ro,[a("div",So,[a("button",{onClick:oe,disabled:d(b)===0,class:"px-4 py-2 border border-dark-600 rounded-claude-md hover:bg-dark-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium text-gray-300"}," ← Anterior ",8,No),a("div",To,[l[22]||(l[22]=ee(" Acertos: ",-1)),a("span",Mo,O(d(x)),1),ee(" / "+O(d(m)),1)]),d(b)<d(_).length-1?(w(),k("button",{key:0,onClick:L,class:"px-4 py-2 bg-claude-primary dark:bg-gradient-to-r dark:from-primary-500 dark:to-primary-600 text-white hover:bg-claude-hover dark:hover:from-primary-600 dark:hover:to-primary-700 transition-all duration-200 shadow-claude-sm hover:shadow-claude-md text-white rounded-claude-md hover:from-claude-hover hover:to-primary-700 dark:hover:from-primary-600 dark:hover:to-primary-700 transition-colors font-medium"}," Próxima → ")):(w(),k("button",{key:1,onClick:F,class:"px-4 py-2 bg-claude-primary dark:bg-gradient-to-r dark:from-primary-500 dark:to-primary-600 text-white hover:bg-claude-hover dark:hover:from-primary-600 dark:hover:to-primary-700 transition-all duration-200 shadow-claude-sm hover:shadow-claude-md text-white rounded-claude-md hover:from-claude-hover hover:to-primary-700 dark:hover:from-primary-600 dark:hover:to-primary-700 transition-colors font-medium"}," Ver Resultados "))])])):K("",!0)])])):K("",!0)]),_:1})]))}}),Do=Object.assign(Je(Go,[["__scopeId","data-v-9ed2bc60"]]),{__name:"AIExercisesModal"});export{Do as _,At as u};
