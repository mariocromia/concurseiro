import { c as defineEventHandler, e as serverSupabaseClient, g as createError, i as getQuery } from '../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const index_get = defineEventHandler(async (event) => {
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    console.log("\u{1F537} [Goals API] Authentication check:", { userId: user == null ? void 0 : user.id, authError });
    if (authError || !user) {
      console.error("\u274C [Goals API] Unauthorized");
      throw createError({ statusCode: 401, message: "Unauthorized" });
    }
    const query = getQuery(event);
    const status = query.status;
    console.log("\u{1F537} [Goals API] Fetching goals for user:", user.id, "with status filter:", status);
    let queryBuilder = supabase.from("goals").select(`
        *,
        subject:subjects(id, name, color, icon),
        checklist_items:goal_checklist_items(
          id,
          description,
          is_completed,
          order_index,
          completed_at,
          created_at
        )
      `).eq("user_id", user.id).order("created_at", { ascending: false });
    if (status && ["in_progress", "completed", "overdue"].includes(status)) {
      queryBuilder = queryBuilder.eq("status", status);
    }
    const { data, error } = await queryBuilder;
    console.log("\u{1F537} [Goals API] Query result:", {
      dataCount: (data == null ? void 0 : data.length) || 0,
      error,
      firstGoal: data == null ? void 0 : data[0]
    });
    if (error) {
      console.error("\u274C [Goals API] Database error:", error);
      throw createError({
        statusCode: 500,
        message: `Database error: ${error.message}`
      });
    }
    const goalsWithProgress = data.map((goal) => {
      var _a, _b;
      const totalItems = ((_a = goal.checklist_items) == null ? void 0 : _a.length) || 0;
      const completedItems = ((_b = goal.checklist_items) == null ? void 0 : _b.filter((item) => item.is_completed).length) || 0;
      const progressPercentage = totalItems > 0 ? Math.round(completedItems / totalItems * 100) : 0;
      const targetDate = new Date(goal.target_date);
      const today = /* @__PURE__ */ new Date();
      today.setHours(0, 0, 0, 0);
      targetDate.setHours(0, 0, 0, 0);
      const daysRemaining = Math.ceil((targetDate.getTime() - today.getTime()) / (1e3 * 60 * 60 * 24));
      return {
        ...goal,
        total_items: totalItems,
        completed_items: completedItems,
        progress_percentage: progressPercentage,
        days_remaining: daysRemaining
      };
    });
    console.log("\u2705 [Goals API] Returning:", goalsWithProgress.length, "goals");
    return {
      success: true,
      data: goalsWithProgress
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
