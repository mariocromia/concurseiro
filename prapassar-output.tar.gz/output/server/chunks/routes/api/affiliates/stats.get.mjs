import { c as defineEventHandler, e as serverSupabaseClient, f as serverSupabaseUser, g as createError, i as getQuery } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const stats_get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const query = getQuery(event);
  const period = query.period || "month";
  const status = query.status || "all";
  const startDate = query.start_date;
  const endDate = query.end_date;
  try {
    const { data: affiliate, error: affiliateError } = await supabase.from("affiliates").select("*").eq("user_id", user.id).single();
    if (affiliateError || !affiliate) {
      throw createError({
        statusCode: 404,
        message: "Voc\xEA n\xE3o \xE9 um afiliado"
      });
    }
    const now = /* @__PURE__ */ new Date();
    let dateFilter = "";
    if (period === "today") {
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      dateFilter = today.toISOString();
    } else if (period === "week") {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1e3);
      dateFilter = weekAgo.toISOString();
    } else if (period === "month") {
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1e3);
      dateFilter = monthAgo.toISOString();
    } else if (period === "custom" && startDate) {
      dateFilter = new Date(startDate).toISOString();
    }
    let referralsQuery = supabase.from("affiliate_referrals").select(`
        *,
        users (
          email,
          full_name
        ),
        subscriptions (
          status,
          current_period_end,
          subscription_plans (
            name,
            price
          )
        )
      `).eq("affiliate_id", affiliate.id);
    if (dateFilter) {
      referralsQuery = referralsQuery.gte("created_at", dateFilter);
    }
    if (period === "custom" && endDate) {
      referralsQuery = referralsQuery.lte("created_at", new Date(endDate).toISOString());
    }
    if (status !== "all") {
      referralsQuery = referralsQuery.eq("status", status);
    }
    const { data: referrals, error: referralsError } = await referralsQuery.order("created_at", { ascending: false });
    if (referralsError) {
      throw referralsError;
    }
    const { data: commissions, error: commissionsError } = await supabase.from("affiliate_commissions").select("*").eq("affiliate_id", affiliate.id).order("created_at", { ascending: false });
    if (commissionsError) {
      throw commissionsError;
    }
    const { data: withdrawals, error: withdrawalsError } = await supabase.from("affiliate_withdrawals").select("*").eq("affiliate_id", affiliate.id).order("created_at", { ascending: false });
    if (withdrawalsError) {
      throw withdrawalsError;
    }
    const { count: totalClicks } = await supabase.from("affiliate_clicks").select("*", { count: "exact", head: true }).eq("affiliate_id", affiliate.id);
    const trialReferrals = (referrals == null ? void 0 : referrals.filter((r) => r.status === "trial")) || [];
    const activeReferrals = (referrals == null ? void 0 : referrals.filter((r) => r.status === "active")) || [];
    const paidReferrals = (commissions == null ? void 0 : commissions.filter((c) => c.status === "paid")) || [];
    const canceledReferrals = (referrals == null ? void 0 : referrals.filter((r) => ["canceled", "expired"].includes(r.status))) || [];
    const availableCommissions = (commissions == null ? void 0 : commissions.filter((c) => c.status === "available")) || [];
    const pendingCommissions = (commissions == null ? void 0 : commissions.filter((c) => c.status === "pending")) || [];
    const conversionRate = totalClicks && totalClicks > 0 ? (((referrals == null ? void 0 : referrals.length) || 0) / totalClicks * 100).toFixed(2) : "0.00";
    const chartData = generateChartData(referrals || [], commissions || []);
    return {
      affiliate: {
        id: affiliate.id,
        coupon_code: affiliate.coupon_code,
        tracking_link: affiliate.tracking_link,
        status: affiliate.status,
        total_earnings: affiliate.total_earnings,
        available_balance: affiliate.available_balance,
        withdrawn_balance: affiliate.withdrawn_balance
      },
      totals: {
        total_referrals: (referrals == null ? void 0 : referrals.length) || 0,
        active_referrals: activeReferrals.length,
        paid_referrals: paidReferrals.length,
        total_commission: affiliate.total_earnings,
        available_balance: affiliate.available_balance
      },
      stats: {
        total_clicks: totalClicks || 0,
        total_referrals: (referrals == null ? void 0 : referrals.length) || 0,
        trial_referrals: trialReferrals.length,
        active_referrals: activeReferrals.length,
        canceled_referrals: canceledReferrals.length,
        conversion_rate: conversionRate
      },
      referrals: referrals || [],
      commissions: commissions || [],
      withdrawals: withdrawals || [],
      chart_data: chartData,
      summary: {
        pending_commissions: pendingCommissions.reduce((sum, c) => sum + parseFloat(c.amount), 0),
        available_commissions: availableCommissions.reduce((sum, c) => sum + parseFloat(c.amount), 0),
        pending_withdrawals: (withdrawals == null ? void 0 : withdrawals.filter((w) => w.status === "pending").length) || 0
      }
    };
  } catch (error) {
    console.error("Erro ao buscar estat\xEDsticas:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao buscar estat\xEDsticas"
    });
  }
});
function generateChartData(referrals, commissions) {
  const days = 30;
  const now = /* @__PURE__ */ new Date();
  const dailyConversions = [];
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1e3);
    const dateStr = date.toISOString().split("T")[0];
    const conversionsOnDay = referrals.filter((r) => {
      const refDate = new Date(r.created_at).toISOString().split("T")[0];
      return refDate === dateStr;
    }).length;
    dailyConversions.push({
      date: dateStr,
      conversions: conversionsOnDay
    });
  }
  const trialCount = referrals.filter((r) => r.status === "trial").length;
  const activeCount = referrals.filter((r) => r.status === "active").length;
  const canceledCount = referrals.filter((r) => ["canceled", "expired"].includes(r.status)).length;
  const paidCount = commissions.filter((c) => c.status === "paid").length;
  return {
    daily_conversions: dailyConversions,
    status_distribution: {
      pending: trialCount,
      active: activeCount,
      paid: paidCount,
      canceled: canceledCount
    }
  };
}

export { stats_get as default };
//# sourceMappingURL=stats.get.mjs.map
