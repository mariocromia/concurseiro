import { c as defineEventHandler, e as serverSupabaseClient, r as readBody, g as createError } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const validateCoupon_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const body = await readBody(event);
  const { coupon_code } = body;
  if (!coupon_code) {
    throw createError({
      statusCode: 400,
      message: "Cupom \xE9 obrigat\xF3rio"
    });
  }
  try {
    const { data: coupon, error: couponError } = await supabase.from("affiliate_coupons").select("*").ilike("code", coupon_code).eq("active", true).single();
    if (couponError || !coupon) {
      return {
        valid: false,
        message: "Cupom inv\xE1lido ou n\xE3o encontrado"
      };
    }
    const { data: affiliate, error: affiliateError } = await supabase.from("affiliates").select("id, status").eq("id", coupon.affiliate_id).single();
    if (affiliateError || !affiliate) {
      return {
        valid: false,
        message: "Afiliado n\xE3o encontrado"
      };
    }
    if (affiliate.status !== "active") {
      return {
        valid: false,
        message: "Cupom n\xE3o est\xE1 mais ativo"
      };
    }
    return {
      valid: true,
      coupon: {
        code: coupon.code,
        discount_percentage: coupon.discount_percentage,
        affiliate_id: coupon.affiliate_id
      }
    };
  } catch (error) {
    console.error("Erro ao validar cupom:", error);
    return {
      valid: false,
      message: "Erro ao validar cupom"
    };
  }
});

export { validateCoupon_post as default };
//# sourceMappingURL=validate-coupon.post.mjs.map
