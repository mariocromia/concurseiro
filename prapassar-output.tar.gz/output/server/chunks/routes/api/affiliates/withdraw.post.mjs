import { c as defineEventHandler, e as serverSupabaseClient, f as serverSupabaseUser, r as readBody, g as createError } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const withdraw_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = await serverSupabaseUser(event);
  const body = await readBody(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const { amount, cpf, pix_key } = body;
  if (!amount || !cpf) {
    throw createError({
      statusCode: 400,
      message: "Valor e CPF s\xE3o obrigat\xF3rios"
    });
  }
  if (amount < 50) {
    throw createError({
      statusCode: 400,
      message: "Valor m\xEDnimo para saque \xE9 R$ 50,00"
    });
  }
  try {
    const { data: affiliate, error: affiliateError } = await supabase.from("affiliates").select("*").eq("user_id", user.id).single();
    if (affiliateError || !affiliate) {
      throw createError({
        statusCode: 404,
        message: "Voc\xEA n\xE3o \xE9 um afiliado"
      });
    }
    if (affiliate.available_balance < amount) {
      throw createError({
        statusCode: 400,
        message: "Saldo insuficiente para saque"
      });
    }
    if (affiliate.cpf !== cpf) {
      throw createError({
        statusCode: 400,
        message: "CPF n\xE3o corresponde ao cadastrado"
      });
    }
    const { data: withdrawal, error: withdrawalError } = await supabase.from("affiliate_withdrawals").insert({
      affiliate_id: affiliate.id,
      amount,
      cpf,
      pix_key: pix_key || cpf,
      status: "pending"
    }).select().single();
    if (withdrawalError) {
      throw withdrawalError;
    }
    await supabase.from("affiliate_commissions").update({ status: "withdrawn" }).eq("affiliate_id", affiliate.id).eq("status", "available");
    return {
      success: true,
      withdrawal,
      message: "Solicita\xE7\xE3o de saque enviada com sucesso!"
    };
  } catch (error) {
    console.error("Erro ao solicitar saque:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao solicitar saque"
    });
  }
});

export { withdraw_post as default };
//# sourceMappingURL=withdraw.post.mjs.map
