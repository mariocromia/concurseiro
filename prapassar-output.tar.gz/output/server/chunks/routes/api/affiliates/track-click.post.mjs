import { c as defineEventHandler, e as serverSupabaseClient, r as readBody, g as createError } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const trackClick_post = defineEventHandler(async (event) => {
  var _a;
  const supabase = await serverSupabaseClient(event);
  const body = await readBody(event);
  const { ref_code } = body;
  if (!ref_code) {
    throw createError({
      statusCode: 400,
      message: "C\xF3digo de refer\xEAncia \xE9 obrigat\xF3rio"
    });
  }
  try {
    const { data: affiliate, error: affiliateError } = await supabase.from("affiliates").select("*").ilike("coupon_code", ref_code).single();
    if (affiliateError || !affiliate) {
      throw createError({
        statusCode: 404,
        message: "Afiliado n\xE3o encontrado"
      });
    }
    const headers = event.node.req.headers;
    const ip = headers["x-forwarded-for"] || headers["x-real-ip"] || ((_a = event.node.req.socket) == null ? void 0 : _a.remoteAddress);
    const userAgent = headers["user-agent"];
    const referer = headers["referer"] || headers["referrer"];
    await supabase.from("affiliate_clicks").insert({
      affiliate_id: affiliate.id,
      ip_address: Array.isArray(ip) ? ip[0] : ip,
      user_agent: userAgent,
      referer,
      converted: false
    });
    return {
      success: true,
      affiliate_id: affiliate.id
    };
  } catch (error) {
    console.error("Erro ao rastrear clique:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao rastrear clique"
    });
  }
});

export { trackClick_post as default };
//# sourceMappingURL=track-click.post.mjs.map
