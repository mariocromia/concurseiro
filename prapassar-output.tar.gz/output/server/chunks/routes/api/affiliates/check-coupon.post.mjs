import { c as defineEventHandler, e as serverSupabaseClient, r as readBody, g as createError } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const checkCoupon_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const body = await readBody(event);
  const { coupon_code } = body;
  if (!coupon_code) {
    throw createError({
      statusCode: 400,
      message: "Cupom \xE9 obrigat\xF3rio"
    });
  }
  try {
    const { data: existingCoupon } = await supabase.from("affiliates").select("*").ilike("coupon_code", coupon_code).single();
    return {
      available: !existingCoupon,
      message: existingCoupon ? "Cupom j\xE1 est\xE1 em uso" : "Cupom dispon\xEDvel"
    };
  } catch (error) {
    console.error("Erro ao verificar cupom:", error);
    throw createError({
      statusCode: 500,
      message: "Erro ao verificar cupom"
    });
  }
});

export { checkCoupon_post as default };
//# sourceMappingURL=check-coupon.post.mjs.map
