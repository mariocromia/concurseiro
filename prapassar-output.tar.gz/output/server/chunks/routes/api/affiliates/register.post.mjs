import { c as defineEventHandler, e as serverSupabaseClient, f as serverSupabaseUser, g as createError, r as readBody, v as validateBody, h as affiliateRegisterSchema } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const register_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const body = await readBody(event);
  const { coupon_code, cpf } = validateBody(affiliateRegisterSchema, body);
  try {
    const { data: existingAffiliate } = await supabase.from("affiliates").select("*").eq("user_id", user.id).single();
    if (existingAffiliate) {
      throw createError({
        statusCode: 400,
        message: "Voc\xEA j\xE1 \xE9 um afiliado"
      });
    }
    const { data: existingCoupon } = await supabase.from("affiliates").select("*").ilike("coupon_code", coupon_code).single();
    if (existingCoupon) {
      throw createError({
        statusCode: 400,
        message: "Este nome de cupom j\xE1 est\xE1 em uso"
      });
    }
    const tracking_link = `https://seuapp.com/register?ref=${coupon_code}`;
    const { data: affiliate, error: affiliateError } = await supabase.from("affiliates").insert({
      user_id: user.id,
      coupon_code: coupon_code.toUpperCase(),
      tracking_link,
      cpf,
      status: "active"
    }).select().single();
    if (affiliateError) {
      throw affiliateError;
    }
    await supabase.from("affiliate_coupons").insert({
      affiliate_id: affiliate.id,
      code: coupon_code.toUpperCase(),
      discount_percentage: 20,
      active: true
    });
    return {
      success: true,
      affiliate,
      message: "Cadastro de afiliado realizado com sucesso!"
    };
  } catch (error) {
    console.error("Erro ao cadastrar afiliado:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao cadastrar afiliado"
    });
  }
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
