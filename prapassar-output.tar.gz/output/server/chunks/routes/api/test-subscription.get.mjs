import { c as defineEventHandler, f as serverSupabaseUser, e as serverSupabaseClient } from '../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const testSubscription_get = defineEventHandler(async (event) => {
  var _a;
  try {
    console.log("\n========================================");
    console.log("\u{1F50D} TESTE DE SUBSCRIPTION - INICIANDO");
    console.log("========================================\n");
    const user = await serverSupabaseUser(event);
    console.log("1\uFE0F\u20E3 AUTENTICA\xC7\xC3O:");
    console.log("   - User ID:", user == null ? void 0 : user.id);
    console.log("   - Email:", user == null ? void 0 : user.email);
    console.log("   - User completo:", JSON.stringify(user, null, 2));
    if (!user) {
      return {
        success: false,
        error: "Usu\xE1rio n\xE3o autenticado",
        message: "Fa\xE7a login primeiro"
      };
    }
    const supabase = await serverSupabaseClient(event);
    console.log("\n2\uFE0F\u20E3 BUSCANDO DADOS NA TABELA users:");
    const { data: userData, error: userError } = await supabase.from("users").select("*").eq("id", user.id).single();
    console.log("   - Query executada: SELECT * FROM users WHERE id =", user.id);
    console.log("   - Erro?", userError);
    console.log("   - Dados retornados:", JSON.stringify(userData, null, 2));
    if (userError) {
      console.log("   \u274C ERRO AO BUSCAR USU\xC1RIO:", userError);
      return {
        success: false,
        error: "Erro ao buscar dados do usu\xE1rio",
        details: userError,
        message: "Verifique se a tabela users existe e tem RLS configurado"
      };
    }
    if (!userData) {
      console.log("   \u274C USU\xC1RIO N\xC3O ENCONTRADO NA TABELA users");
      return {
        success: false,
        error: "Usu\xE1rio n\xE3o encontrado na tabela users",
        message: "O registro do usu\xE1rio n\xE3o existe na tabela users. Voc\xEA precisa criar um registro.",
        sql: `INSERT INTO users (id, email, subscription_type, trial_ends_at)
              VALUES ('${user.id}', '${user.email}', 'pro', NOW() + INTERVAL '14 days');`
      };
    }
    console.log("\n3\uFE0F\u20E3 VERIFICA\xC7\xC3O DE CAMPOS:");
    console.log("   - subscription_type existe?", "subscription_type" in userData);
    console.log("   - subscription_type valor:", userData.subscription_type);
    console.log("   - subscription_type tipo:", typeof userData.subscription_type);
    console.log("   - trial_ends_at existe?", "trial_ends_at" in userData);
    console.log("   - trial_ends_at valor:", userData.trial_ends_at);
    const subscriptionType = (_a = userData == null ? void 0 : userData.subscription_type) == null ? void 0 : _a.toString().toLowerCase();
    const isPro = subscriptionType === "pro";
    const isPlus = subscriptionType === "plus";
    const isTrial = (userData == null ? void 0 : userData.trial_ends_at) && new Date(userData.trial_ends_at) > /* @__PURE__ */ new Date();
    console.log("\n4\uFE0F\u20E3 VALIDA\xC7\xC3O DE ACESSO:");
    console.log("   - subscriptionType (normalizado):", subscriptionType);
    console.log("   - isPro:", isPro);
    console.log("   - isPlus:", isPlus);
    console.log("   - isTrial:", isTrial);
    console.log("   - Acesso liberado?", isPro || isPlus || isTrial);
    console.log("\n5\uFE0F\u20E3 VERIFICANDO ESTRUTURA DA TABELA:");
    const { data: columns } = await supabase.from("users").select("*").limit(1);
    if (columns && columns.length > 0) {
      console.log("   - Colunas dispon\xEDveis:", Object.keys(columns[0]));
    }
    const hasAccess = isPro || isPlus || isTrial;
    console.log("\n========================================");
    console.log(hasAccess ? "\u2705 USU\xC1RIO TEM ACESSO" : "\u274C USU\xC1RIO N\xC3O TEM ACESSO");
    console.log("========================================\n");
    return {
      success: true,
      user: {
        id: user.id,
        email: user.email
      },
      userData,
      validation: {
        subscriptionType,
        isPro,
        isPlus,
        isTrial,
        hasAccess
      },
      availableColumns: columns && columns.length > 0 ? Object.keys(columns[0]) : [],
      recommendation: !hasAccess ? "Execute o SQL em FIX_ADD_SUBSCRIPTION_FIELD.sql para corrigir" : "Tudo OK! O usu\xE1rio tem acesso."
    };
  } catch (error) {
    console.error("\n\u274C ERRO NO TESTE:", error);
    return {
      success: false,
      error: "Erro ao executar teste",
      details: error.message,
      stack: error.stack
    };
  }
});

export { testSubscription_get as default };
//# sourceMappingURL=test-subscription.get.mjs.map
