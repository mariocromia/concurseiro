import { c as defineEventHandler, e as serverSupabaseClient, f as serverSupabaseUser, g as createError } from '../../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const withdrawals_get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  if (user.email !== "mariocromia@gmail.com") {
    throw createError({
      statusCode: 403,
      message: "Acesso negado"
    });
  }
  try {
    const { data: withdrawals, error } = await supabase.from("affiliate_withdrawals").select(`
        *,
        affiliates (
          id,
          coupon_code,
          user_id,
          users:user_id (
            email
          )
        )
      `).order("created_at", { ascending: false });
    if (error) {
      throw error;
    }
    return {
      withdrawals: withdrawals || []
    };
  } catch (error) {
    console.error("Erro ao listar saques:", error);
    throw createError({
      statusCode: 500,
      message: "Erro ao listar saques"
    });
  }
});

export { withdrawals_get as default };
//# sourceMappingURL=withdrawals.get.mjs.map
