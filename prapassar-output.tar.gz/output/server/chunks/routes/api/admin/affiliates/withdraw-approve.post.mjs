import { c as defineEventHandler, e as serverSupabaseClient, f as serverSupabaseUser, r as readBody, g as createError } from '../../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const withdrawApprove_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = await serverSupabaseUser(event);
  const body = await readBody(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  if (user.email !== "mariocromia@gmail.com") {
    throw createError({
      statusCode: 403,
      message: "Acesso negado"
    });
  }
  const { withdrawal_id, action, rejection_reason } = body;
  if (!withdrawal_id || !action) {
    throw createError({
      statusCode: 400,
      message: "ID do saque e a\xE7\xE3o s\xE3o obrigat\xF3rios"
    });
  }
  if (!["approve", "reject", "mark_paid"].includes(action)) {
    throw createError({
      statusCode: 400,
      message: "A\xE7\xE3o inv\xE1lida"
    });
  }
  try {
    const updateData = {
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (action === "approve") {
      updateData.status = "approved";
      updateData.approved_at = (/* @__PURE__ */ new Date()).toISOString();
      updateData.approved_by = user.id;
    } else if (action === "reject") {
      if (!rejection_reason) {
        throw createError({
          statusCode: 400,
          message: "Motivo da rejei\xE7\xE3o \xE9 obrigat\xF3rio"
        });
      }
      updateData.status = "rejected";
      updateData.rejection_reason = rejection_reason;
    } else if (action === "mark_paid") {
      updateData.status = "paid";
      updateData.paid_at = (/* @__PURE__ */ new Date()).toISOString();
    }
    const { data: withdrawal, error } = await supabase.from("affiliate_withdrawals").update(updateData).eq("id", withdrawal_id).select().single();
    if (error) {
      throw error;
    }
    return {
      success: true,
      withdrawal,
      message: `Saque ${action === "approve" ? "aprovado" : action === "reject" ? "rejeitado" : "marcado como pago"} com sucesso`
    };
  } catch (error) {
    console.error("Erro ao processar saque:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao processar saque"
    });
  }
});

export { withdrawApprove_post as default };
//# sourceMappingURL=withdraw-approve.post.mjs.map
