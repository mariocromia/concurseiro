import { c as defineEventHandler, e as serverSupabaseClient, f as serverSupabaseUser, g as createError } from '../../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const list_get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  if (user.email !== "mariocromia@gmail.com") {
    throw createError({
      statusCode: 403,
      message: "Acesso negado"
    });
  }
  try {
    const { data: affiliates, error } = await supabase.from("affiliates").select(`
        *,
        users:user_id (
          email
        )
      `).order("created_at", { ascending: false });
    if (error) {
      throw error;
    }
    const affiliatesWithStats = await Promise.all(
      (affiliates || []).map(async (affiliate) => {
        const { count: totalReferrals } = await supabase.from("affiliate_referrals").select("*", { count: "exact", head: true }).eq("affiliate_id", affiliate.id);
        const { count: activeReferrals } = await supabase.from("affiliate_referrals").select("*", { count: "exact", head: true }).eq("affiliate_id", affiliate.id).eq("status", "active");
        const { count: trialReferrals } = await supabase.from("affiliate_referrals").select("*", { count: "exact", head: true }).eq("affiliate_id", affiliate.id).eq("status", "trial");
        const { count: pendingCommissions } = await supabase.from("affiliate_commissions").select("*", { count: "exact", head: true }).eq("affiliate_id", affiliate.id).eq("status", "pending");
        const { count: totalClicks } = await supabase.from("affiliate_clicks").select("*", { count: "exact", head: true }).eq("affiliate_id", affiliate.id);
        return {
          ...affiliate,
          stats: {
            total_referrals: totalReferrals || 0,
            active_referrals: activeReferrals || 0,
            trial_referrals: trialReferrals || 0,
            pending_commissions: pendingCommissions || 0,
            total_clicks: totalClicks || 0,
            conversion_rate: totalClicks && totalClicks > 0 ? ((totalReferrals || 0) / totalClicks * 100).toFixed(2) : "0.00"
          }
        };
      })
    );
    return {
      affiliates: affiliatesWithStats
    };
  } catch (error) {
    console.error("Erro ao listar afiliados:", error);
    throw createError({
      statusCode: 500,
      message: "Erro ao listar afiliados"
    });
  }
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
