import { c as defineEventHandler, e as serverSupabaseClient, g as createError } from '../../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const setupAffiliates_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  try {
    const schemaPath = path.join(process.cwd(), "scripts", "affiliate-schema.sql");
    const fixRlsPath = path.join(process.cwd(), "scripts", "fix-affiliate-rls.sql");
    const schemaSql = fs.readFileSync(schemaPath, "utf-8");
    const fixRlsSql = fs.readFileSync(fixRlsPath, "utf-8");
    console.log("Executando affiliate-schema.sql...");
    const { error: schemaError } = await supabase.rpc("exec_sql", {
      sql_query: schemaSql
    });
    if (schemaError) {
      console.error("Erro no schema:", schemaError);
    }
    console.log("Executando fix-affiliate-rls.sql...");
    const { error: fixError } = await supabase.rpc("exec_sql", {
      sql_query: fixRlsSql
    });
    if (fixError) {
      console.error("Erro no fix RLS:", fixError);
    }
    return {
      success: true,
      message: "Tabelas de afiliados configuradas com sucesso!",
      errors: {
        schema: schemaError == null ? void 0 : schemaError.message,
        fixRls: fixError == null ? void 0 : fixError.message
      }
    };
  } catch (error) {
    console.error("Erro ao executar setup:", error);
    throw createError({
      statusCode: 500,
      message: error.message
    });
  }
});

export { setupAffiliates_post as default };
//# sourceMappingURL=setup-affiliates.post.mjs.map
