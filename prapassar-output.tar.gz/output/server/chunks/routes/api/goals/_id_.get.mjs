import { c as defineEventHandler, e as serverSupabaseClient, g as createError, j as getRouterParam } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const _id__get = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    console.log("\u{1F537} [Goal by ID API] Authentication check:", { userId: user == null ? void 0 : user.id, authError });
    if (authError || !user) {
      console.error("\u274C [Goal by ID API] Unauthorized");
      throw createError({ statusCode: 401, message: "Unauthorized" });
    }
    const goalId = getRouterParam(event, "id");
    console.log("\u{1F537} [Goal by ID API] Fetching goal:", goalId, "for user:", user.id);
    if (!goalId) {
      console.error("\u274C [Goal by ID API] Missing goal ID");
      throw createError({ statusCode: 400, message: "ID da meta \xE9 obrigat\xF3rio" });
    }
    const { data, error } = await supabase.from("goals").select(`
        *,
        subject:subjects(id, name, color, icon),
        checklist_items:goal_checklist_items(
          id,
          description,
          is_completed,
          order_index,
          completed_at,
          created_at
        )
      `).eq("id", goalId).eq("user_id", user.id).single();
    console.log("\u{1F537} [Goal by ID API] Query result:", {
      hasData: !!data,
      error,
      goalName: data == null ? void 0 : data.name
    });
    if (error) {
      console.error("\u274C [Goal by ID API] Database error:", error);
      if (error.code === "PGRST116") {
        throw createError({
          statusCode: 404,
          message: "Meta n\xE3o encontrada"
        });
      }
      throw createError({
        statusCode: 500,
        message: `Database error: ${error.message}`
      });
    }
    const totalItems = ((_a = data.checklist_items) == null ? void 0 : _a.length) || 0;
    const completedItems = ((_b = data.checklist_items) == null ? void 0 : _b.filter((item) => item.is_completed).length) || 0;
    const progressPercentage = totalItems > 0 ? Math.round(completedItems / totalItems * 100) : 0;
    const targetDate = new Date(data.target_date);
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    targetDate.setHours(0, 0, 0, 0);
    const daysRemaining = Math.ceil((targetDate.getTime() - today.getTime()) / (1e3 * 60 * 60 * 24));
    if (data.checklist_items) {
      data.checklist_items.sort((a, b) => a.order_index - b.order_index);
    }
    const responseData = {
      ...data,
      total_items: totalItems,
      completed_items: completedItems,
      progress_percentage: progressPercentage,
      days_remaining: daysRemaining
    };
    console.log("\u2705 [Goal by ID API] Returning goal:", {
      id: responseData.id,
      name: responseData.name,
      totalItems,
      completedItems,
      progressPercentage
    });
    return {
      success: true,
      data: responseData
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
