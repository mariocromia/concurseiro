import { c as defineEventHandler, e as serverSupabaseClient, g as createError, r as readBody } from '../../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const update_post = defineEventHandler(async (event) => {
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw createError({ statusCode: 401, message: "Unauthorized" });
    }
    const body = await readBody(event);
    if (!body.item_id) {
      throw createError({ statusCode: 400, message: "ID do item \xE9 obrigat\xF3rio" });
    }
    if (!body.description || typeof body.description !== "string" || body.description.trim().length === 0) {
      throw createError({ statusCode: 400, message: "Descri\xE7\xE3o n\xE3o pode ser vazia" });
    }
    const { data: item, error: fetchError } = await supabase.from("goal_checklist_items").select(`
        id,
        goal_id,
        goal:goals!inner(user_id)
      `).eq("id", body.item_id).single();
    if (fetchError || !item) {
      throw createError({
        statusCode: 404,
        message: "Item do checklist n\xE3o encontrado"
      });
    }
    if (item.goal.user_id !== user.id) {
      throw createError({
        statusCode: 403,
        message: "Acesso negado"
      });
    }
    const { error: updateError } = await supabase.from("goal_checklist_items").update({ description: body.description.trim() }).eq("id", body.item_id);
    if (updateError) {
      throw createError({
        statusCode: 500,
        message: `Erro ao atualizar item: ${updateError.message}`
      });
    }
    const { data: updatedGoal, error: goalError } = await supabase.from("goals").select(`
        *,
        subject:subjects(id, name, color, icon),
        checklist_items:goal_checklist_items(
          id,
          description,
          is_completed,
          order_index,
          completed_at,
          created_at
        )
      `).eq("id", item.goal_id).single();
    if (goalError) {
      throw createError({
        statusCode: 500,
        message: `Erro ao buscar meta atualizada: ${goalError.message}`
      });
    }
    return {
      success: true,
      message: "Item atualizado com sucesso!",
      data: updatedGoal
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map
