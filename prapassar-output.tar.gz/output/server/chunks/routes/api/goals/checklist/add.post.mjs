import { c as defineEventHandler, e as serverSupabaseClient, r as readBody, g as createError } from '../../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const add_post = defineEventHandler(async (event) => {
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw createError2({ statusCode: 401, message: "Unauthorized" });
    }
    const body = await readBody(event);
    if (!body.goal_id) {
      throw createError2({ statusCode: 400, message: "ID da meta \xE9 obrigat\xF3rio" });
    }
    if (!body.description || typeof body.description !== "string" || body.description.trim().length === 0) {
      throw createError2({ statusCode: 400, message: "Descri\xE7\xE3o do item \xE9 obrigat\xF3ria" });
    }
    const { data: goal, error: goalError } = await supabase.from("goals").select("id, user_id").eq("id", body.goal_id).eq("user_id", user.id).single();
    if (goalError || !goal) {
      throw createError2({
        statusCode: 404,
        message: "Meta n\xE3o encontrada"
      });
    }
    const { data: items, error: itemsError } = await supabase.from("goal_checklist_items").select("order_index").eq("goal_id", body.goal_id).order("order_index", { ascending: false }).limit(1);
    if (itemsError) {
      throw createError2({
        statusCode: 500,
        message: `Erro ao buscar itens: ${itemsError.message}`
      });
    }
    const maxOrderIndex = items && items.length > 0 ? items[0].order_index : -1;
    const newOrderIndex = maxOrderIndex + 1;
    const { data: newItem, error: createError2 } = await supabase.from("goal_checklist_items").insert({
      goal_id: body.goal_id,
      description: body.description.trim(),
      is_completed: false,
      order_index: newOrderIndex
    }).select().single();
    if (createError2) {
      throw createError2({
        statusCode: 500,
        message: `Erro ao criar item: ${createError2.message}`
      });
    }
    const { data: updatedGoal, error: fetchError } = await supabase.from("goals").select(`
        *,
        subject:subjects(id, name, color, icon),
        checklist_items:goal_checklist_items(
          id,
          description,
          is_completed,
          order_index,
          completed_at,
          created_at
        )
      `).eq("id", body.goal_id).single();
    if (fetchError) {
      throw createError2({
        statusCode: 500,
        message: `Erro ao buscar meta atualizada: ${fetchError.message}`
      });
    }
    return {
      success: true,
      message: "Item adicionado com sucesso!",
      data: updatedGoal,
      new_item: newItem
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { add_post as default };
//# sourceMappingURL=add.post.mjs.map
