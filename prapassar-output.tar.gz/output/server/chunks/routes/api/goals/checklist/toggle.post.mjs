import { c as defineEventHandler, e as serverSupabaseClient, g as createError, r as readBody } from '../../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const toggle_post = defineEventHandler(async (event) => {
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw createError({ statusCode: 401, message: "Unauthorized" });
    }
    const body = await readBody(event);
    console.log("\u{1F537} [Toggle Checklist] User ID:", user.id);
    console.log("\u{1F537} [Toggle Checklist] Item ID:", body.item_id);
    if (!body.item_id) {
      throw createError({ statusCode: 400, message: "ID do item \xE9 obrigat\xF3rio" });
    }
    const { data: item, error: fetchError } = await supabase.from("goal_checklist_items").select(`
        id,
        is_completed,
        goal_id
      `).eq("id", body.item_id).single();
    console.log("\u{1F537} [Toggle Checklist] Item fetch result:", { item, fetchError });
    if (fetchError || !item) {
      console.error("\u274C [Toggle Checklist] Failed to fetch item:", fetchError);
      throw createError({
        statusCode: 404,
        message: "Item do checklist n\xE3o encontrado"
      });
    }
    const { data: goal, error: goalError } = await supabase.from("goals").select("id, user_id").eq("id", item.goal_id).eq("user_id", user.id).single();
    console.log("\u{1F537} [Toggle Checklist] Goal ownership check:", { goal, goalError });
    if (goalError || !goal) {
      console.error("\u274C [Toggle Checklist] Access denied:", goalError);
      throw createError({
        statusCode: 403,
        message: "Acesso negado"
      });
    }
    const newCompletionState = !item.is_completed;
    const updateData = {
      is_completed: newCompletionState
    };
    if (newCompletionState) {
      updateData.completed_at = (/* @__PURE__ */ new Date()).toISOString();
    } else {
      updateData.completed_at = null;
    }
    console.log("\u{1F537} [Toggle Checklist] Update data:", updateData);
    const { error: updateError } = await supabase.from("goal_checklist_items").update(updateData).eq("id", body.item_id);
    console.log("\u{1F537} [Toggle Checklist] Update result:", { updateError });
    if (updateError) {
      console.error("\u274C [Toggle Checklist] Update failed:", updateError);
      throw createError({
        statusCode: 500,
        message: `Erro ao atualizar item: ${updateError.message}`
      });
    }
    console.log("\u2705 [Toggle Checklist] Item updated successfully");
    const { data: updatedGoal, error: goalFetchError } = await supabase.from("goals").select(`
        *,
        subject:subjects(id, name, color, icon),
        checklist_items:goal_checklist_items(
          id,
          description,
          is_completed,
          order_index,
          completed_at,
          created_at
        )
      `).eq("id", item.goal_id).single();
    console.log("\u{1F537} [Toggle Checklist] Fetched updated goal:", { updatedGoal, goalFetchError });
    if (goalFetchError) {
      console.error("\u274C [Toggle Checklist] Failed to fetch updated goal:", goalFetchError);
      throw createError({
        statusCode: 500,
        message: `Erro ao buscar meta atualizada: ${goalFetchError.message}`
      });
    }
    console.log("\u2705 [Toggle Checklist] Success! Returning updated goal");
    return {
      success: true,
      message: newCompletionState ? "Item marcado como conclu\xEDdo!" : "Item desmarcado",
      data: updatedGoal
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { toggle_post as default };
//# sourceMappingURL=toggle.post.mjs.map
