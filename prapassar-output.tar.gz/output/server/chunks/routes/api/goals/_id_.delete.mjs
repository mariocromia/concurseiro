import { c as defineEventHandler, e as serverSupabaseClient, g as createError, j as getRouterParam } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const _id__delete = defineEventHandler(async (event) => {
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw createError({ statusCode: 401, message: "Unauthorized" });
    }
    const goalId = getRouterParam(event, "id");
    if (!goalId) {
      throw createError({ statusCode: 400, message: "ID da meta \xE9 obrigat\xF3rio" });
    }
    const { error } = await supabase.from("goals").delete().eq("id", goalId).eq("user_id", user.id);
    if (error) {
      throw createError({
        statusCode: 500,
        message: `Erro ao deletar meta: ${error.message}`
      });
    }
    return {
      success: true,
      message: "Meta deletada com sucesso!"
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
