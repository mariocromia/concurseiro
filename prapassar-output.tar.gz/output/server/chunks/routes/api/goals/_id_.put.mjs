import { c as defineEventHandler, e as serverSupabaseClient, g as createError, j as getRouterParam, r as readBody } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const _id__put = defineEventHandler(async (event) => {
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw createError({ statusCode: 401, message: "Unauthorized" });
    }
    const goalId = getRouterParam(event, "id");
    if (!goalId) {
      throw createError({ statusCode: 400, message: "ID da meta \xE9 obrigat\xF3rio" });
    }
    const body = await readBody(event);
    if (body.name !== void 0 && (typeof body.name !== "string" || body.name.trim().length === 0)) {
      throw createError({ statusCode: 400, message: "Nome da meta n\xE3o pode ser vazio" });
    }
    if (body.target_date !== void 0) {
      const targetDate = new Date(body.target_date);
      const today = /* @__PURE__ */ new Date();
      today.setHours(0, 0, 0, 0);
      targetDate.setHours(0, 0, 0, 0);
      if (targetDate < today) {
        throw createError({ statusCode: 400, message: "A data de conclus\xE3o n\xE3o pode ser anterior a hoje" });
      }
    }
    const { data: existingGoal, error: fetchError } = await supabase.from("goals").select("id").eq("id", goalId).eq("user_id", user.id).single();
    if (fetchError || !existingGoal) {
      throw createError({
        statusCode: 404,
        message: "Meta n\xE3o encontrada"
      });
    }
    const updateData = {};
    if (body.name !== void 0) updateData.name = body.name.trim();
    if (body.subject_id !== void 0) updateData.subject_id = body.subject_id;
    if (body.target_date !== void 0) updateData.target_date = body.target_date;
    const { error: updateError } = await supabase.from("goals").update(updateData).eq("id", goalId).eq("user_id", user.id);
    if (updateError) {
      throw createError({
        statusCode: 500,
        message: `Erro ao atualizar meta: ${updateError.message}`
      });
    }
    const { data: updatedGoal, error: getError } = await supabase.from("goals").select(`
        *,
        subject:subjects(id, name, color, icon),
        checklist_items:goal_checklist_items(
          id,
          description,
          is_completed,
          order_index,
          completed_at,
          created_at
        )
      `).eq("id", goalId).single();
    if (getError) {
      throw createError({
        statusCode: 500,
        message: `Erro ao buscar meta atualizada: ${getError.message}`
      });
    }
    return {
      success: true,
      message: "Meta atualizada com sucesso!",
      data: updatedGoal
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
