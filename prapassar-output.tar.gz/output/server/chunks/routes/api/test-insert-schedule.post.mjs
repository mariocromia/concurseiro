import { c as defineEventHandler, e as serverSupabaseClient, g as createError } from '../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const testInsertSchedule_post = defineEventHandler(async (event) => {
  console.log("\u{1F9EA} === TESTE DE INSER\xC7\xC3O DIRETA ===");
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      console.error("\u274C Erro de autentica\xE7\xE3o:", authError);
      throw createError({ statusCode: 401, message: "Unauthorized" });
    }
    console.log("\u2705 Usu\xE1rio autenticado:", user.id);
    const testData = {
      user_id: user.id,
      title: "TESTE - Inser\xE7\xE3o Direta",
      scheduled_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      // Data de hoje
      // Tentar APENAS com campos antigos primeiro
      scheduled_time: "14:00",
      planned_duration: 60,
      study_type: "conteudo",
      status: "pending"
    };
    console.log("\u{1F4E6} Dados de teste:", JSON.stringify(testData, null, 2));
    const { data, error: insertError } = await supabase.from("study_schedules").insert(testData).select();
    if (insertError) {
      console.error("\u274C ERRO ao inserir:", insertError);
      return {
        success: false,
        error: {
          code: insertError.code,
          message: insertError.message,
          details: insertError.details,
          hint: insertError.hint
        }
      };
    }
    console.log("\u2705 SUCESSO! Dados inseridos:", data);
    return {
      success: true,
      message: "Registro de teste criado com sucesso!",
      data
    };
  } catch (err) {
    console.error("\u274C EXCEPTION:", err);
    throw createError({
      statusCode: err.statusCode || 500,
      message: err.message || "Internal server error"
    });
  }
});

export { testInsertSchedule_post as default };
//# sourceMappingURL=test-insert-schedule.post.mjs.map
