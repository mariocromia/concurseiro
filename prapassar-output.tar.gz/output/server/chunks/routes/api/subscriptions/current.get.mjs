import { c as defineEventHandler, e as serverSupabaseClient, g as createError } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const current_get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = event.context.user;
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  try {
    const { data: subscription, error } = await supabase.from("subscriptions").select(`
        *,
        plan:subscription_plans(*)
      `).eq("user_id", user.id).in("status", ["active", "trial", "past_due"]).order("created_at", { ascending: false }).limit(1).single();
    if (error && error.code !== "PGRST116") {
      throw error;
    }
    let nextPayment = null;
    if (subscription) {
      const { data: payment } = await supabase.from("payments").select("*").eq("subscription_id", subscription.id).in("status", ["pending", "confirmed"]).order("due_date", { ascending: true }).limit(1).single();
      nextPayment = payment;
    }
    return {
      success: true,
      data: {
        subscription: subscription || null,
        nextPayment
      }
    };
  } catch (error) {
    console.error("Erro ao buscar assinatura:", error);
    throw createError({
      statusCode: 500,
      message: "Erro ao buscar assinatura"
    });
  }
});

export { current_get as default };
//# sourceMappingURL=current.get.mjs.map
