import { c as defineEventHandler, e as serverSupabaseClient, g as createError } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const plans_get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const { data: plans, error } = await supabase.from("subscription_plans").select("*").eq("active", true).order("price", { ascending: true });
  if (error) {
    throw createError({
      statusCode: 500,
      message: "Erro ao buscar planos",
      data: error
    });
  }
  return {
    success: true,
    data: plans
  };
});

export { plans_get as default };
//# sourceMappingURL=plans.get.mjs.map
