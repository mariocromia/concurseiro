import { c as defineEventHandler, e as serverSupabaseClient, g as createError, i as getQuery } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const payments_get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const user = event.context.user;
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const query = getQuery(event);
  const limit = Number(query.limit) || 10;
  const offset = Number(query.offset) || 0;
  try {
    const { data: payments, error, count } = await supabase.from("payments").select("*, subscription:subscriptions(*, plan:subscription_plans(*))", { count: "exact" }).eq("user_id", user.id).order("created_at", { ascending: false }).range(offset, offset + limit - 1);
    if (error) {
      throw error;
    }
    return {
      success: true,
      data: payments,
      pagination: {
        total: count || 0,
        limit,
        offset
      }
    };
  } catch (error) {
    console.error("Erro ao buscar pagamentos:", error);
    throw createError({
      statusCode: 500,
      message: "Erro ao buscar hist\xF3rico de pagamentos"
    });
  }
});

export { payments_get as default };
//# sourceMappingURL=payments.get.mjs.map
