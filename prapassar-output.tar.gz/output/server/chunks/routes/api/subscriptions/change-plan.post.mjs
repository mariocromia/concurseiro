import { c as defineEventHandler, e as serverSupabaseClient, l as useAsaas, g as createError, r as readBody } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const changePlan_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const asaas = useAsaas();
  const user = event.context.user;
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const body = await readBody(event);
  const { newPlanId } = body;
  if (!newPlanId) {
    throw createError({
      statusCode: 400,
      message: "ID do novo plano \xE9 obrigat\xF3rio"
    });
  }
  try {
    const { data: currentSubscription, error: subError } = await supabase.from("subscriptions").select("*, plan:subscription_plans(*)").eq("user_id", user.id).in("status", ["active", "trial"]).order("created_at", { ascending: false }).limit(1).single();
    if (subError || !currentSubscription) {
      throw createError({
        statusCode: 404,
        message: "Assinatura ativa n\xE3o encontrada"
      });
    }
    const { data: newPlan, error: planError } = await supabase.from("subscription_plans").select("*").eq("id", newPlanId).single();
    if (planError || !newPlan) {
      throw createError({
        statusCode: 404,
        message: "Novo plano n\xE3o encontrado"
      });
    }
    const changeType = newPlan.price > currentSubscription.plan.price ? "upgrade" : "downgrade";
    const { data: asaasCustomer } = await supabase.from("asaas_customers").select("*").eq("user_id", user.id).single();
    if (!asaasCustomer) {
      throw createError({
        statusCode: 404,
        message: "Cliente Asaas n\xE3o encontrado"
      });
    }
    if (currentSubscription.asaas_subscription_id) {
      await asaas.deleteSubscription(currentSubscription.asaas_subscription_id);
    }
    const now = /* @__PURE__ */ new Date();
    const nextDueDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1e3);
    const asaasSubscriptionData = await asaas.createSubscription({
      customer: asaasCustomer.asaas_customer_id,
      billingType: "CREDIT_CARD",
      value: newPlan.price,
      nextDueDate: nextDueDate.toISOString().split("T")[0],
      cycle: "MONTHLY",
      description: `Assinatura ${newPlan.display_name}`,
      externalReference: user.id
    });
    await supabase.from("subscriptions").update({
      status: "canceled",
      canceled_at: now.toISOString()
    }).eq("id", currentSubscription.id);
    const { data: newSubscription, error: newSubError } = await supabase.from("subscriptions").insert({
      user_id: user.id,
      plan_id: newPlanId,
      asaas_subscription_id: asaasSubscriptionData.id,
      status: "active",
      current_period_start: now.toISOString(),
      current_period_end: nextDueDate.toISOString()
    }).select("*, plan:subscription_plans(*)").single();
    if (newSubError) {
      throw newSubError;
    }
    await supabase.from("subscription_changes").insert({
      user_id: user.id,
      subscription_id: newSubscription.id,
      from_plan_id: currentSubscription.plan_id,
      to_plan_id: newPlanId,
      change_type: changeType,
      effective_date: now.toISOString()
    });
    return {
      success: true,
      data: newSubscription,
      message: `Plano alterado com sucesso para ${newPlan.display_name}`
    };
  } catch (error) {
    console.error("Erro ao alterar plano:", error);
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao alterar plano"
    });
  }
});

export { changePlan_post as default };
//# sourceMappingURL=change-plan.post.mjs.map
