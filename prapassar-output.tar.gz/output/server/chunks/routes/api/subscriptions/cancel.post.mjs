import { c as defineEventHandler, e as serverSupabaseClient, l as useAsaas, g as createError, r as readBody } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const cancel_post = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const asaas = useAsaas();
  const user = event.context.user;
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const body = await readBody(event);
  const { subscriptionId, cancelAtPeriodEnd = true, reason } = body;
  try {
    const { data: subscription, error: subError } = await supabase.from("subscriptions").select("*, plan:subscription_plans(*)").eq("id", subscriptionId).eq("user_id", user.id).single();
    if (subError || !subscription) {
      throw createError({
        statusCode: 404,
        message: "Assinatura n\xE3o encontrada"
      });
    }
    if (subscription.asaas_subscription_id) {
      await asaas.deleteSubscription(subscription.asaas_subscription_id);
    }
    const updateData = {
      cancel_at_period_end: cancelAtPeriodEnd,
      canceled_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (!cancelAtPeriodEnd) {
      updateData.status = "canceled";
      updateData.current_period_end = (/* @__PURE__ */ new Date()).toISOString();
    }
    const { data: updatedSubscription, error: updateError } = await supabase.from("subscriptions").update(updateData).eq("id", subscriptionId).select().single();
    if (updateError) {
      throw updateError;
    }
    await supabase.from("subscription_changes").insert({
      user_id: user.id,
      subscription_id: subscriptionId,
      from_plan_id: subscription.plan_id,
      to_plan_id: subscription.plan_id,
      change_type: "cancel",
      effective_date: cancelAtPeriodEnd ? subscription.current_period_end : (/* @__PURE__ */ new Date()).toISOString(),
      reason
    });
    return {
      success: true,
      data: updatedSubscription,
      message: cancelAtPeriodEnd ? "Assinatura ser\xE1 cancelada ao final do per\xEDodo" : "Assinatura cancelada imediatamente"
    };
  } catch (error) {
    console.error("Erro ao cancelar assinatura:", error);
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao cancelar assinatura"
    });
  }
});

export { cancel_post as default };
//# sourceMappingURL=cancel.post.mjs.map
