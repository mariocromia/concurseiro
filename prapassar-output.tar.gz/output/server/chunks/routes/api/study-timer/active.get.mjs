import { c as defineEventHandler, f as serverSupabaseUser, g as createError, e as serverSupabaseClient } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const active_get = defineEventHandler(async (event) => {
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "N\xE3o autenticado"
    });
  }
  const supabase = await serverSupabaseClient(event);
  const { data: timer, error } = await supabase.from("study_timers").select("*, subjects(name, color, icon)").eq("user_id", user.id).eq("is_running", true).maybeSingle();
  if (error) {
    throw createError({
      statusCode: 500,
      message: `Erro ao buscar timer: ${error.message}`
    });
  }
  if (!timer) {
    return {
      hasActiveTimer: false,
      timer: null
    };
  }
  const now = /* @__PURE__ */ new Date();
  const startTime = new Date(timer.start_time);
  const currentElapsed = Math.floor((now.getTime() - startTime.getTime()) / 1e3);
  const totalElapsedSeconds = (timer.elapsed_seconds || 0) + currentElapsed;
  const hours = Math.floor(totalElapsedSeconds / 3600);
  const minutes = Math.floor(totalElapsedSeconds % 3600 / 60);
  const seconds = totalElapsedSeconds % 60;
  const formattedTime = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  return {
    hasActiveTimer: true,
    timer: {
      id: timer.id,
      startTime: timer.start_time,
      elapsedSeconds: totalElapsedSeconds,
      formattedTime,
      isRunning: true,
      subjectId: timer.subject_id,
      studyType: timer.study_type,
      plannedQuestions: timer.planned_questions,
      activityName: timer.activity_name,
      subject: timer.subjects ? {
        name: timer.subjects.name,
        color: timer.subjects.color,
        icon: timer.subjects.icon
      } : null
    }
  };
});

export { active_get as default };
//# sourceMappingURL=active.get.mjs.map
