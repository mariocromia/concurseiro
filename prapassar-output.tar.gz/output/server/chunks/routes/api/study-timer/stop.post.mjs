import { c as defineEventHandler, f as serverSupabaseUser, g as createError, r as readBody, e as serverSupabaseClient } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const stop_post = defineEventHandler(async (event) => {
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "N\xE3o autenticado"
    });
  }
  const body = await readBody(event);
  const { timer_id, notes, completed_questions, correct_questions } = body;
  if (!timer_id) {
    throw createError({
      statusCode: 400,
      message: "timer_id \xE9 obrigat\xF3rio"
    });
  }
  const supabase = await serverSupabaseClient(event);
  const { data: timer, error: timerError } = await supabase.from("study_timers").select("*").eq("id", timer_id).eq("user_id", user.id).eq("is_running", true).maybeSingle();
  if (timerError) {
    throw createError({
      statusCode: 500,
      message: `Erro ao buscar timer: ${timerError.message}`
    });
  }
  if (!timer) {
    throw createError({
      statusCode: 404,
      message: "Timer n\xE3o encontrado ou j\xE1 foi encerrado"
    });
  }
  const now = /* @__PURE__ */ new Date();
  const startTime = new Date(timer.start_time);
  const currentElapsed = Math.floor((now.getTime() - startTime.getTime()) / 1e3);
  const totalSeconds = (timer.elapsed_seconds || 0) + currentElapsed;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor(totalSeconds % 3600 / 60);
  const seconds = totalSeconds % 60;
  const totalFormatted = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  const { error: sessionError } = await supabase.from("study_sessions").insert({
    user_id: user.id,
    subject_id: timer.subject_id,
    started_at: timer.start_time,
    ended_at: now.toISOString(),
    duration: totalSeconds,
    notes: notes || null,
    study_type: timer.study_type || "conteudo",
    completed_questions: completed_questions || 0,
    correct_questions: correct_questions || 0
  });
  if (sessionError) {
    throw createError({
      statusCode: 500,
      message: `Erro ao salvar sess\xE3o: ${sessionError.message}`
    });
  }
  const scheduleData = {
    user_id: user.id,
    subject_id: timer.subject_id || null,
    scheduled_date: new Date(timer.start_time).toISOString().split("T")[0],
    scheduled_time: new Date(timer.start_time).toTimeString().split(" ")[0].substring(0, 5),
    planned_duration: Math.floor(totalSeconds / 60),
    study_type: timer.study_type,
    planned_questions: timer.planned_questions,
    status: "completed",
    completed_at: now.toISOString(),
    actual_duration: Math.floor(totalSeconds / 60),
    completed_questions: completed_questions || null,
    correct_questions: correct_questions || null,
    notes: notes || null,
    is_recurring: false
  };
  const { error: scheduleError } = await supabase.from("study_schedules").insert(scheduleData);
  if (scheduleError) {
    console.warn("\u26A0\uFE0F Erro ao salvar no calend\xE1rio:", scheduleError);
  }
  if (timer.subject_id) {
    try {
      const dayOffsets = [1, 7, 14, 30, 60, 120, 240];
      const revisions = dayOffsets.map((days, idx) => {
        const revisionDate = new Date(now);
        revisionDate.setDate(revisionDate.getDate() + days);
        return {
          user_id: user.id,
          subject_id: timer.subject_id,
          page_id: null,
          revision_number: idx + 1,
          scheduled_date: revisionDate.toISOString(),
          status: "pending"
        };
      });
      await supabase.from("revisions").insert(revisions);
    } catch (e) {
      console.warn("\u26A0\uFE0F Falha ao agendar revis\xF5es:", e);
    }
  }
  if (timer.subject_id) {
    const { data: subject } = await supabase.from("subjects").select("total_study_time").eq("id", timer.subject_id).single();
    const currentTime = (subject == null ? void 0 : subject.total_study_time) || 0;
    await supabase.from("subjects").update({ total_study_time: currentTime + totalSeconds }).eq("id", timer.subject_id);
  }
  await supabase.from("study_timers").update({
    is_running: false,
    end_time: now.toISOString(),
    elapsed_seconds: totalSeconds
  }).eq("id", timer_id);
  await supabase.from("study_timers").delete().eq("id", timer_id);
  return {
    success: true,
    timer: {
      id: timer_id,
      totalSeconds,
      totalFormatted,
      startedAt: timer.start_time,
      endedAt: now.toISOString()
    }
  };
});

export { stop_post as default };
//# sourceMappingURL=stop.post.mjs.map
