import { c as defineEventHandler, e as serverSupabaseClient, g as createError, r as readBody } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const save_post = defineEventHandler(async (event) => {
  var _a, _b;
  console.log("[API exercises/save] ===== IN\xCDCIO =====");
  const client = await serverSupabaseClient(event);
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  const userId = (_b = (_a = sessionData == null ? void 0 : sessionData.session) == null ? void 0 : _a.user) == null ? void 0 : _b.id;
  console.log("[API exercises/save] User ID:", userId);
  if (sessionError || !userId) {
    console.error("[API exercises/save] \u274C Erro de autentica\xE7\xE3o:", sessionError);
    throw createError({
      statusCode: 401,
      message: "N\xE3o autenticado"
    });
  }
  const body = await readBody(event);
  console.log("[API exercises/save] Body recebido:", JSON.stringify(body, null, 2));
  const {
    subject_id,
    title,
    total_questions,
    correct_answers,
    score_percentage,
    questions_data
  } = body;
  if (!title || !total_questions || correct_answers === void 0) {
    throw createError({
      statusCode: 400,
      message: "Dados incompletos. Necess\xE1rio: title, total_questions, correct_answers"
    });
  }
  const score = score_percentage || Math.round(correct_answers / total_questions * 100);
  console.log("[API exercises/save] Dados a inserir:", {
    user_id: userId,
    subject_id: subject_id || null,
    title,
    total_questions,
    correct_answers,
    score_percentage: score
  });
  try {
    const { data, error } = await client.from("saved_exercise_results").insert({
      user_id: userId,
      subject_id: subject_id || null,
      title,
      total_questions,
      correct_answers,
      score_percentage: score,
      questions_data: questions_data || {}
    }).select().single();
    if (error) {
      console.error("[API exercises/save] \u274C Erro Supabase:", error);
      console.error("[API exercises/save] Error details:", JSON.stringify(error, null, 2));
      throw createError({
        statusCode: 500,
        message: `Erro ao salvar exerc\xEDcio: ${error.message}`
      });
    }
    console.log("[API exercises/save] \u2705 Exerc\xEDcio salvo com sucesso:", data == null ? void 0 : data.id);
    return {
      success: true,
      data
    };
  } catch (err) {
    console.error("[API exercises/save] Erro:", err);
    throw createError({
      statusCode: err.statusCode || 500,
      message: err.message || "Erro ao salvar exerc\xEDcio"
    });
  }
});

export { save_post as default };
//# sourceMappingURL=save.post.mjs.map
