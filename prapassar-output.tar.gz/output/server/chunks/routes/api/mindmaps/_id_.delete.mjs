import { c as defineEventHandler, e as serverSupabaseClient, g as createError, j as getRouterParam } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const _id__delete = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      message: "ID do mapa mental \xE9 obrigat\xF3rio"
    });
  }
  try {
    const { error } = await supabase.from("mindmaps").delete().eq("id", id).eq("user_id", user.id);
    if (error) throw error;
    return {
      success: true,
      message: "Mapa mental deletado com sucesso"
    };
  } catch (error) {
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao deletar mapa mental"
    });
  }
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
