import { c as defineEventHandler, r as readBody, g as createError, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import { GoogleGenerativeAI } from '@google/generative-ai';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const generateFromText_post = defineEventHandler(async (event) => {
  console.log("[GENERATE] Handler iniciado");
  try {
    console.log("[GENERATE] Lendo body...");
    const body = await readBody(event);
    const { text } = body;
    console.log("[GENERATE] Recebido texto:", (text == null ? void 0 : text.substring(0, 50)) + "...");
    if (!text || text.trim().length === 0) {
      console.log("[GENERATE] Texto vazio");
      throw createError({
        statusCode: 400,
        message: "Texto \xE9 obrigat\xF3rio"
      });
    }
    const config = useRuntimeConfig();
    const apiKey = config.public.googleAiApiKey;
    console.log("[GENERATE] API Key configurada:", apiKey ? "Sim" : "N\xE3o");
    if (!apiKey) {
      throw createError({
        statusCode: 500,
        message: "API Key do Google AI n\xE3o configurada"
      });
    }
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    console.log("[GENERATE] Modelo Gemini inicializado");
    const prompt = `Analise o seguinte texto e crie uma estrutura hier\xE1rquica de mapa mental organizada logicamente.

TEXTO:
${text}

Retorne APENAS um JSON v\xE1lido (sem markdown, sem explica\xE7\xF5es) no seguinte formato:
{
  "title": "T\xEDtulo principal do mapa mental",
  "nodes": [
    {
      "id": "1",
      "text": "Ideia principal",
      "parent_id": null,
      "level": 0
    },
    {
      "id": "2",
      "text": "Subt\xF3pico 1",
      "parent_id": "1",
      "level": 1
    }
  ]
}

Regras:
- O n\xF3 raiz (level 0) sempre tem parent_id null
- IDs devem ser strings num\xE9ricas sequenciais
- Organize em no m\xE1ximo 3-4 n\xEDveis de profundidade
- Crie entre 5-15 n\xF3s no total
- Seja conciso nos textos (m\xE1ximo 50 caracteres por n\xF3)
- Agrupe ideias relacionadas sob um mesmo pai`;
    console.log("[GENERATE] Gerando conte\xFAdo com IA...");
    const result = await model.generateContent(prompt);
    const response = result.response;
    const responseText = response.text();
    console.log("[GENERATE] Resposta da IA recebida:", responseText.substring(0, 100) + "...");
    let cleanText = responseText.trim();
    if (cleanText.startsWith("```json")) {
      cleanText = cleanText.replace(/```json\n?/, "").replace(/```\n?$/, "");
    } else if (cleanText.startsWith("```")) {
      cleanText = cleanText.replace(/```\n?/, "").replace(/```\n?$/, "");
    }
    console.log("[GENERATE] Texto limpo:", cleanText.substring(0, 100) + "...");
    const data = JSON.parse(cleanText);
    console.log("[GENERATE] JSON parseado:", JSON.stringify(data).substring(0, 100) + "...");
    if (!data.title || !data.nodes || !Array.isArray(data.nodes)) {
      throw new Error("Estrutura de resposta inv\xE1lida");
    }
    const nodesWithPositions = calculateNodePositions(data.nodes);
    console.log("[GENERATE] N\xF3s com posi\xE7\xF5es calculadas:", nodesWithPositions.length);
    return {
      success: true,
      data: {
        title: data.title,
        nodes: nodesWithPositions
      }
    };
  } catch (error) {
    console.error("[GENERATE] Erro ao gerar mapa mental:", error);
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao processar texto com IA"
    });
  }
});
function calculateNodePositions(nodes) {
  const positioned = [];
  const nodesByLevel = {};
  nodes.forEach((node) => {
    const level = node.level || 0;
    if (!nodesByLevel[level]) nodesByLevel[level] = [];
    nodesByLevel[level].push(node);
  });
  Object.keys(nodesByLevel).sort((a, b) => Number(a) - Number(b)).forEach((levelKey) => {
    const level = Number(levelKey);
    const levelNodes = nodesByLevel[level];
    levelNodes.forEach((node, index) => {
      const x = level * 300;
      const y = index * 150 - levelNodes.length * 75 + 200;
      positioned.push({
        ...node,
        position_x: x,
        position_y: y,
        color: getColorByLevel(level)
      });
    });
  });
  return positioned;
}
function getColorByLevel(level) {
  const colors = ["#3b82f6", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981"];
  return colors[level % colors.length];
}

export { generateFromText_post as default };
//# sourceMappingURL=generate-from-text.post.mjs.map
