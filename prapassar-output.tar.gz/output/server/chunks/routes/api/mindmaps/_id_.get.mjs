import { c as defineEventHandler, e as serverSupabaseClient, g as createError, j as getRouterParam } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const _id__get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      message: "ID do mapa mental \xE9 obrigat\xF3rio"
    });
  }
  try {
    console.log("[GET-MINDMAP] Buscando mindmap ID:", id);
    console.log("[GET-MINDMAP] User ID:", user.id);
    const { data: mindmap, error: mindmapError } = await supabase.from("mindmaps").select("*").eq("id", id).eq("user_id", user.id).single();
    console.log("[GET-MINDMAP] Mindmap encontrado:", !!mindmap);
    console.log("[GET-MINDMAP] Mindmap error:", mindmapError);
    if (mindmapError) throw mindmapError;
    if (!mindmap) {
      throw createError({
        statusCode: 404,
        message: "Mapa mental n\xE3o encontrado"
      });
    }
    console.log("[GET-MINDMAP] Buscando n\xF3s para mindmap_id:", id);
    const { data: nodes, error: nodesError } = await supabase.from("mindmap_nodes").select("*").eq("mindmap_id", id);
    console.log("[GET-MINDMAP] N\xF3s encontrados:", (nodes == null ? void 0 : nodes.length) || 0);
    console.log("[GET-MINDMAP] N\xF3s error:", nodesError);
    if (nodes && nodes.length > 0) {
      console.log("[GET-MINDMAP] Primeiro n\xF3:", JSON.stringify(nodes[0], null, 2));
    }
    if (nodesError) throw nodesError;
    return {
      success: true,
      data: {
        ...mindmap,
        nodes: nodes || []
      }
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao buscar mapa mental"
    });
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
