import { c as defineEventHandler, e as serverSupabaseClient, g as createError, j as getRouterParam, r as readBody } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const _id__put = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { title, description } = body;
  if (!id) {
    throw createError({
      statusCode: 400,
      message: "ID do mapa mental \xE9 obrigat\xF3rio"
    });
  }
  try {
    const { data: mindmap, error } = await supabase.from("mindmaps").update({
      title: title || void 0,
      description: description !== void 0 ? description : void 0
    }).eq("id", id).eq("user_id", user.id).select().single();
    if (error) throw error;
    return {
      success: true,
      data: mindmap
    };
  } catch (error) {
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao atualizar mapa mental"
    });
  }
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
