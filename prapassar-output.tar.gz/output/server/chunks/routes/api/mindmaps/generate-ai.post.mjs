import { c as defineEventHandler, e as serverSupabaseClient, g as createError, r as readBody, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import { GoogleGenerativeAI } from '@google/generative-ai';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const generateAi_post = defineEventHandler(async (event) => {
  console.log("[GENERATE-AI] ========================================");
  console.log("[GENERATE-AI] Iniciando handler...");
  console.log("[GENERATE-AI] URL:", event.node.req.url);
  console.log("[GENERATE-AI] Method:", event.node.req.method);
  try {
    console.log("[GENERATE-AI] Obtendo Supabase client e user...");
    const supabase = await serverSupabaseClient(event);
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    console.log("[GENERATE-AI] User completo:", JSON.stringify(user, null, 2));
    console.log("[GENERATE-AI] User ID:", user == null ? void 0 : user.id);
    console.log("[GENERATE-AI] User ID type:", typeof (user == null ? void 0 : user.id));
    console.log("[GENERATE-AI] Auth error:", authError);
    if (authError || !user) {
      console.error("[GENERATE-AI] Usu\xE1rio n\xE3o autenticado!");
      console.error("[GENERATE-AI] Auth error:", authError);
      throw createError({
        statusCode: 401,
        message: "Usu\xE1rio n\xE3o autenticado"
      });
    }
    if (!user.id) {
      console.error("[GENERATE-AI] User existe mas n\xE3o tem ID!");
      console.error("[GENERATE-AI] User object:", user);
      throw createError({
        statusCode: 401,
        message: "Erro de autentica\xE7\xE3o: user.id est\xE1 undefined"
      });
    }
    console.log("[GENERATE-AI] Lendo body da requisi\xE7\xE3o...");
    const body = await readBody(event);
    console.log("[GENERATE-AI] Body recebido:", JSON.stringify(body, null, 2));
    const { chapter_id, title } = body;
    console.log("[GENERATE-AI] Par\xE2metros extra\xEDdos:");
    console.log("[GENERATE-AI]   - chapter_id:", chapter_id, "(type:", typeof chapter_id, ")");
    console.log("[GENERATE-AI]   - title:", title, "(type:", typeof title, ")");
    if (!chapter_id) {
      console.error("[GENERATE-AI] \u274C chapter_id n\xE3o informado!");
      throw createError({
        statusCode: 400,
        message: "\xC9 necess\xE1rio selecionar um cap\xEDtulo para gerar o mapa mental."
      });
    }
    if (!title || title.trim() === "") {
      console.error("[GENERATE-AI] \u274C title n\xE3o informado!");
      throw createError({
        statusCode: 400,
        message: "\xC9 necess\xE1rio informar um t\xEDtulo para o mapa mental."
      });
    }
    console.log("[GENERATE-AI] \u2705 Valida\xE7\xE3o OK! Prosseguindo...");
    console.log("[GENERATE-AI] Buscando informa\xE7\xF5es do cap\xEDtulo:", chapter_id);
    const { data: chapter, error: chapterError } = await supabase.from("chapters").select("id, title, subject_id").eq("id", chapter_id).single();
    if (chapterError || !chapter) {
      console.error("[GENERATE-AI] Erro ao buscar cap\xEDtulo:", chapterError);
      throw createError({
        statusCode: 404,
        message: "Cap\xEDtulo n\xE3o encontrado. Por favor, selecione um cap\xEDtulo v\xE1lido."
      });
    }
    console.log("[GENERATE-AI] \u2705 Cap\xEDtulo encontrado:", chapter.title);
    console.log("[GENERATE-AI] Buscando p\xE1ginas do cap\xEDtulo:", chapter_id);
    const { data: pages, error: pagesError } = await supabase.from("pages").select("title, content").eq("chapter_id", chapter_id).order("title");
    console.log("[GENERATE-AI] Resultado da busca de p\xE1ginas:", { count: pages == null ? void 0 : pages.length, error: pagesError });
    if (pagesError) {
      console.error("[GENERATE-AI] Erro ao buscar p\xE1ginas do cap\xEDtulo:", pagesError);
      throw createError({
        statusCode: 500,
        message: `Erro ao buscar p\xE1ginas do cap\xEDtulo: ${pagesError.message}`
      });
    }
    if (!pages || pages.length === 0) {
      throw createError({
        statusCode: 404,
        message: `O cap\xEDtulo "${chapter.title}" n\xE3o possui p\xE1ginas com conte\xFAdo. Adicione conte\xFAdo ao cap\xEDtulo antes de gerar o mapa mental.`
      });
    }
    const contentText = pages.map((p) => `${p.title || "Sem t\xEDtulo"}
${p.content || ""}`).join("\n\n");
    console.log("[GENERATE-AI] \u2705 Conte\xFAdo de", pages.length, 'p\xE1ginas carregado do cap\xEDtulo "' + chapter.title + '"');
    console.log("[GENERATE-AI] Tamanho do conte\xFAdo:", contentText.length, "caracteres");
    console.log("[GENERATE-AI] \u2705 Acesso autorizado para todos os usu\xE1rios!");
    const config = useRuntimeConfig();
    const apiKey = config.googleAiApiKey;
    console.log("[GENERATE-AI] API Key configurada?", !!apiKey);
    console.log("[GENERATE-AI] API Key (primeiros 10 chars):", apiKey == null ? void 0 : apiKey.substring(0, 10));
    if (!apiKey) {
      throw createError({
        statusCode: 500,
        message: "API Key do Google AI n\xE3o configurada"
      });
    }
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    console.log("[GENERATE-AI] Gerando mapa mental com IA...");
    const prompt = `Analise o seguinte conte\xFAdo e crie uma estrutura hier\xE1rquica de mapa mental organizada logicamente.

CONTE\xDADO:
${contentText.substring(0, 5e3)}

Retorne APENAS um JSON v\xE1lido (sem markdown, sem explica\xE7\xF5es) no seguinte formato:
{
  "nodes": [
    {
      "id": "1",
      "text": "Ideia principal",
      "parent_id": null,
      "level": 0
    },
    {
      "id": "2",
      "text": "Subt\xF3pico 1",
      "parent_id": "1",
      "level": 1
    }
  ]
}

Regras:
- O n\xF3 raiz (level 0) sempre tem parent_id null
- IDs devem ser strings num\xE9ricas sequenciais
- Organize em no m\xE1ximo 3-4 n\xEDveis de profundidade
- Crie entre 8-20 n\xF3s no total
- Seja conciso nos textos (m\xE1ximo 50 caracteres por n\xF3)
- Agrupe ideias relacionadas sob um mesmo pai`;
    const result = await model.generateContent(prompt);
    const response = result.response;
    const responseText = response.text();
    console.log("[GENERATE-AI] Resposta da IA recebida");
    let cleanText = responseText.trim();
    if (cleanText.startsWith("```json")) {
      cleanText = cleanText.replace(/```json\n?/, "").replace(/```\n?$/, "");
    } else if (cleanText.startsWith("```")) {
      cleanText = cleanText.replace(/```\n?/, "").replace(/```\n?$/, "");
    }
    const aiData = JSON.parse(cleanText);
    if (!aiData.nodes || !Array.isArray(aiData.nodes)) {
      throw new Error("Estrutura de resposta inv\xE1lida");
    }
    const nodesWithPositions = calculateNodePositions(aiData.nodes);
    console.log("[GENERATE-AI] N\xF3s com posi\xE7\xF5es calculadas:", nodesWithPositions.length);
    const { data: mindmap, error: mindmapError } = await supabase.from("mindmaps").insert({
      user_id: user.id,
      subject_id: chapter.subject_id,
      // Adicionar subject_id do capítulo
      title,
      description: chapter_id ? "Gerado por IA a partir de cap\xEDtulo" : "Gerado por IA a partir de mat\xE9ria completa"
    }).select().single();
    if (mindmapError) {
      console.error("[GENERATE-AI] Erro ao criar mindmap:", mindmapError);
      throw mindmapError;
    }
    console.log("[GENERATE-AI] Mindmap criado:", mindmap.id);
    const idMap = /* @__PURE__ */ new Map();
    const nodesToInsert = [];
    for (const node of nodesWithPositions) {
      if (!node.parent_id) {
        nodesToInsert.push({
          mindmap_id: mindmap.id,
          parent_id: null,
          text: node.text,
          position_x: node.position_x || 0,
          position_y: node.position_y || 0,
          color: node.color || "#3b82f6"
        });
      }
    }
    if (nodesToInsert.length > 0) {
      const { data: insertedRootNodes, error: rootError } = await supabase.from("mindmap_nodes").insert(nodesToInsert).select();
      if (rootError) throw rootError;
      let rootIndex = 0;
      for (const node of nodesWithPositions) {
        if (!node.parent_id && insertedRootNodes) {
          idMap.set(node.id, insertedRootNodes[rootIndex].id);
          rootIndex++;
        }
      }
    }
    let hasMoreNodes = true;
    let safetyCounter = 0;
    while (hasMoreNodes && safetyCounter < 10) {
      const nodesToInsertNow = [];
      const nodesWithMappedParent = [];
      for (const node of nodesWithPositions) {
        if (idMap.has(node.id)) continue;
        if (node.parent_id && idMap.has(node.parent_id)) {
          nodesWithMappedParent.push(node);
          nodesToInsertNow.push({
            mindmap_id: mindmap.id,
            parent_id: idMap.get(node.parent_id),
            text: node.text,
            position_x: node.position_x || 0,
            position_y: node.position_y || 0,
            color: node.color || "#3b82f6"
          });
        }
      }
      if (nodesToInsertNow.length === 0) {
        hasMoreNodes = false;
      } else {
        const { data: inserted, error: insertError } = await supabase.from("mindmap_nodes").insert(nodesToInsertNow).select();
        if (insertError) throw insertError;
        nodesWithMappedParent.forEach((node, index) => {
          if (inserted) {
            idMap.set(node.id, inserted[index].id);
          }
        });
      }
      safetyCounter++;
    }
    console.log("[GENERATE-AI] Sucesso! Mapa criado:", mindmap.id);
    console.log("[GENERATE-AI] ========================================");
    console.log("[GENERATE-AI] SUCESSO! Retornando mapa mental:", mindmap.id);
    console.log("[GENERATE-AI] ========================================");
    return {
      success: true,
      data: mindmap
    };
  } catch (error) {
    console.error("[GENERATE-AI] ========================================");
    console.error("[GENERATE-AI] ERRO CAPTURADO!");
    console.error("[GENERATE-AI] Tipo:", error.constructor.name);
    console.error("[GENERATE-AI] Message:", error.message);
    console.error("[GENERATE-AI] StatusCode:", error.statusCode);
    console.error("[GENERATE-AI] Stack:", error.stack);
    console.error("[GENERATE-AI] Error completo:", JSON.stringify(error, null, 2));
    console.error("[GENERATE-AI] ========================================");
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao gerar mapa mental com IA"
    });
  }
});
function calculateNodePositions(nodes) {
  const positioned = [];
  const nodesByLevel = {};
  nodes.forEach((node) => {
    const level = node.level || 0;
    if (!nodesByLevel[level]) nodesByLevel[level] = [];
    nodesByLevel[level].push(node);
  });
  Object.keys(nodesByLevel).sort((a, b) => Number(a) - Number(b)).forEach((levelKey) => {
    const level = Number(levelKey);
    const levelNodes = nodesByLevel[level];
    levelNodes.forEach((node, index) => {
      const x = level * 300;
      const y = index * 150 - levelNodes.length * 75 + 200;
      positioned.push({
        ...node,
        position_x: x,
        position_y: y,
        color: getColorByLevel(level)
      });
    });
  });
  return positioned;
}
function getColorByLevel(level) {
  const colors = ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ec4899"];
  return colors[level % colors.length];
}

export { generateAi_post as default };
//# sourceMappingURL=generate-ai.post.mjs.map
