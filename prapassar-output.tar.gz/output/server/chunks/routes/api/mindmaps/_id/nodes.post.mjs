import { c as defineEventHandler, e as serverSupabaseClient, g as createError, j as getRouterParam, r as readBody } from '../../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const nodes_post = defineEventHandler(async (event) => {
  console.log("==========================================");
  console.log("[NODES-POST] ENDPOINT CHAMADO!");
  console.log("==========================================");
  const supabase = await serverSupabaseClient(event);
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  console.log("[NODES-POST] User ID:", user == null ? void 0 : user.id);
  if (authError || !user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { nodes } = body;
  if (!id || !nodes || !Array.isArray(nodes)) {
    throw createError({
      statusCode: 400,
      message: "Dados inv\xE1lidos"
    });
  }
  try {
    const { data: mindmap } = await supabase.from("mindmaps").select("id").eq("id", id).eq("user_id", user.id).single();
    if (!mindmap) {
      throw createError({
        statusCode: 404,
        message: "Mapa mental n\xE3o encontrado"
      });
    }
    await supabase.from("mindmap_nodes").delete().eq("mindmap_id", id);
    if (nodes.length > 0) {
      console.log("[NODES-POST] Salvando", nodes.length, "n\xF3s para mindmap", id);
      const idMapping = {};
      const rootNodes = nodes.filter((node) => !node.parent_id || node.parent_id === null);
      console.log("[NODES-POST] Inserindo", rootNodes.length, "n\xF3s raiz...");
      if (rootNodes.length > 0) {
        const rootData = rootNodes.map((node) => ({
          mindmap_id: id,
          parent_id: null,
          text: node.text || "Sem texto",
          position_x: node.position_x || 0,
          position_y: node.position_y || 0,
          color: node.color || "#3b82f6"
        }));
        const { error: rootError, data: rootInserted } = await supabase.from("mindmap_nodes").insert(rootData).select();
        if (rootError) {
          console.error("[NODES-POST] ERRO ao inserir n\xF3s raiz:", rootError);
          throw rootError;
        }
        rootNodes.forEach((oldNode, index) => {
          if (rootInserted && rootInserted[index]) {
            idMapping[oldNode.id] = rootInserted[index].id;
          }
        });
        console.log("[NODES-POST] \u2705", (rootInserted == null ? void 0 : rootInserted.length) || 0, "n\xF3s raiz inseridos");
      }
      const childNodes = nodes.filter((node) => node.parent_id && node.parent_id !== null);
      console.log("[NODES-POST] Inserindo", childNodes.length, "n\xF3s filhos...");
      if (childNodes.length > 0) {
        const childData = childNodes.map((node) => ({
          mindmap_id: id,
          parent_id: idMapping[node.parent_id] || null,
          // Mapear para novo ID
          text: node.text || "Sem texto",
          position_x: node.position_x || 0,
          position_y: node.position_y || 0,
          color: node.color || "#3b82f6"
        }));
        const { error: childError, data: childInserted } = await supabase.from("mindmap_nodes").insert(childData).select();
        if (childError) {
          console.error("[NODES-POST] ERRO ao inserir n\xF3s filhos:", childError);
          throw childError;
        }
        console.log("[NODES-POST] \u2705", (childInserted == null ? void 0 : childInserted.length) || 0, "n\xF3s filhos inseridos");
      }
      console.log("[NODES-POST] \u2705 TOTAL:", nodes.length, "n\xF3s salvos com sucesso!");
    }
    return {
      success: true,
      message: "N\xF3s atualizados com sucesso"
    };
  } catch (error) {
    console.error("[NODES-POST] ERRO CATCH:", error);
    console.error("[NODES-POST] ERRO DETALHES:", JSON.stringify(error, null, 2));
    const errorMsg = error.message || "Erro ao atualizar n\xF3s";
    if (errorMsg.includes("column") && errorMsg.includes("does not exist")) {
      throw createError({
        statusCode: 500,
        message: `\u26A0\uFE0F BANCO DE DADOS DESATUALIZADO: Execute o arquivo database/EXECUTE_SOMENTE_ESTE_SQL.sql no Supabase SQL Editor. Erro original: ${errorMsg}`
      });
    }
    throw createError({
      statusCode: error.statusCode || 500,
      message: `${errorMsg}. Detalhes: ${JSON.stringify(error.details || error.hint || "Sem detalhes")}`
    });
  }
});

export { nodes_post as default };
//# sourceMappingURL=nodes.post.mjs.map
