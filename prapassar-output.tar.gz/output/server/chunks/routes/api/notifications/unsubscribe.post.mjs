import { c as defineEventHandler, f as serverSupabaseUser, g as createError, r as readBody, e as serverSupabaseClient } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const unsubscribe_post = defineEventHandler(async (event) => {
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Authentication required"
    });
  }
  const body = await readBody(event);
  const { endpoint } = body;
  if (!endpoint) {
    throw createError({
      statusCode: 400,
      message: "Endpoint is required"
    });
  }
  try {
    const supabase = await serverSupabaseClient(event);
    const { error } = await supabase.from("push_subscriptions").delete().eq("user_id", user.id).eq("endpoint", endpoint);
    if (error) throw error;
    return { success: true, message: "Unsubscribed successfully" };
  } catch (error) {
    console.error("[PUSH-UNSUBSCRIBE] Error:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to unsubscribe"
    });
  }
});

export { unsubscribe_post as default };
//# sourceMappingURL=unsubscribe.post.mjs.map
