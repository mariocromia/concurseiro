import { c as defineEventHandler, f as serverSupabaseUser, g as createError, r as readBody, e as serverSupabaseClient } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const subscribe_post = defineEventHandler(async (event) => {
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "Authentication required"
    });
  }
  const body = await readBody(event);
  const { subscription } = body;
  if (!subscription || !subscription.endpoint) {
    throw createError({
      statusCode: 400,
      message: "Invalid subscription object"
    });
  }
  try {
    const supabase = await serverSupabaseClient(event);
    const { data: existing } = await supabase.from("push_subscriptions").select("id").eq("user_id", user.id).eq("endpoint", subscription.endpoint).single();
    if (existing) {
      const { error: error2 } = await supabase.from("push_subscriptions").update({
        subscription_data: subscription,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("id", existing.id);
      if (error2) throw error2;
      return { success: true, message: "Subscription updated" };
    }
    const { error } = await supabase.from("push_subscriptions").insert({
      user_id: user.id,
      endpoint: subscription.endpoint,
      subscription_data: subscription
    });
    if (error) throw error;
    return { success: true, message: "Subscribed successfully" };
  } catch (error) {
    console.error("[PUSH-SUBSCRIBE] Error:", error);
    throw createError({
      statusCode: 500,
      message: "Failed to subscribe"
    });
  }
});

export { subscribe_post as default };
//# sourceMappingURL=subscribe.post.mjs.map
