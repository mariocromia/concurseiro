import { c as defineEventHandler, g as createError } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const publicKey_get = defineEventHandler(async (event) => {
  const publicKey = process.env.VAPID_PUBLIC_KEY;
  if (!publicKey) {
    throw createError({
      statusCode: 500,
      message: "Push notifications not configured"
    });
  }
  return {
    publicKey
  };
});

export { publicKey_get as default };
//# sourceMappingURL=public-key.get.mjs.map
