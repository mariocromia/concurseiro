import { c as defineEventHandler, w as getRequestHeader, x as isAsaasWhitelistedIP, y as logWebhookSecurityEvent, g as createError, z as checkRateLimit, r as readBody, u as useRuntimeConfig, A as verifyAsaasWebhookSignature, v as validateBody, B as asaasWebhookSchema, e as serverSupabaseClient, C as webhookRateLimit } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const asaas_post = defineEventHandler(async (event) => {
  var _a;
  const startTime = Date.now();
  const forwarded = getRequestHeader(event, "x-forwarded-for");
  const clientIP = forwarded ? forwarded.split(",")[0] : getRequestHeader(event, "x-real-ip") || "127.0.0.1";
  if (!isAsaasWhitelistedIP(clientIP)) {
    logWebhookSecurityEvent("ip_blocked", {
      ip: clientIP,
      endpoint: "/api/webhooks/asaas"
    });
    throw createError({
      statusCode: 403,
      message: "Forbidden: IP not whitelisted"
    });
  }
  logWebhookSecurityEvent("ip_allowed", { ip: clientIP });
  await checkRateLimit(
    clientIP,
    webhookRateLimit,
    "Webhook rate limit exceeded"
  );
  const rawBody = await readBody(event);
  const signature = getRequestHeader(event, "x-asaas-signature");
  const config = useRuntimeConfig();
  const webhookSecret = config.asaasWebhookSecret || process.env.ASAAS_WEBHOOK_SECRET || "";
  const isValidSignature = verifyAsaasWebhookSignature(rawBody, signature, webhookSecret);
  if (!isValidSignature) {
    logWebhookSecurityEvent("signature_invalid", {
      ip: clientIP,
      hasSignature: !!signature,
      hasSecret: !!webhookSecret
    });
    throw createError({
      statusCode: 401,
      message: "Unauthorized: Invalid webhook signature"
    });
  }
  logWebhookSecurityEvent("signature_valid", { ip: clientIP });
  const body = validateBody(asaasWebhookSchema, typeof rawBody === "string" ? JSON.parse(rawBody) : rawBody);
  console.log("[WEBHOOK-ASAAS] Webhook recebido e validado:", {
    event: body.event,
    paymentId: (_a = body.payment) == null ? void 0 : _a.id,
    ip: clientIP,
    processingTime: Date.now() - startTime
  });
  const supabase = await serverSupabaseClient(event);
  try {
    const { data: existingWebhook } = await supabase.from("asaas_webhooks").select("id, processed, created_at").eq("asaas_event_id", body.id).single();
    if (existingWebhook) {
      logWebhookSecurityEvent("replay_attempt_blocked", {
        ip: clientIP,
        eventId: body.id,
        eventType: body.event,
        originalCreatedAt: existingWebhook.created_at,
        wasProcessed: existingWebhook.processed
      });
      console.warn("[WEBHOOK-ASAAS] Replay attack blocked:", {
        eventId: body.id,
        eventType: body.event,
        originalCreatedAt: existingWebhook.created_at,
        wasProcessed: existingWebhook.processed
      });
      return {
        success: true,
        message: "Webhook already processed"
      };
    }
    const { data: webhook, error: webhookError } = await supabase.from("asaas_webhooks").insert({
      event_type: body.event,
      asaas_event_id: body.id,
      payload: body,
      processed: false
    }).select().single();
    if (webhookError) {
      console.error("Erro ao salvar webhook:", webhookError);
      throw webhookError;
    }
    try {
      switch (body.event) {
        case "PAYMENT_CREATED":
        case "PAYMENT_UPDATED":
        case "PAYMENT_CONFIRMED":
        case "PAYMENT_RECEIVED":
          await handlePaymentWebhook(supabase, body.payment);
          break;
        case "PAYMENT_OVERDUE":
          await handlePaymentOverdue(supabase, body.payment);
          break;
        case "PAYMENT_DELETED":
        case "PAYMENT_RESTORED":
        case "PAYMENT_REFUNDED":
          await handlePaymentWebhook(supabase, body.payment);
          break;
        case "PAYMENT_AWAITING_RISK_ANALYSIS":
        case "PAYMENT_APPROVED_BY_RISK_ANALYSIS":
        case "PAYMENT_REPROVED_BY_RISK_ANALYSIS":
          await handlePaymentWebhook(supabase, body.payment);
          break;
        default:
          console.log("Tipo de evento n\xE3o tratado:", body.event);
      }
      await supabase.from("asaas_webhooks").update({
        processed: true,
        processed_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("id", webhook.id);
      return {
        success: true,
        message: "Webhook processado com sucesso"
      };
    } catch (processingError) {
      console.error("Erro ao processar webhook:", processingError);
      await supabase.from("asaas_webhooks").update({
        processed: false,
        error_message: processingError.message
      }).eq("id", webhook.id);
      throw processingError;
    }
  } catch (error) {
    console.error("Erro no webhook:", error);
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao processar webhook"
    });
  }
});
async function handlePaymentWebhook(supabase, paymentData) {
  console.log("Processando pagamento:", paymentData.id);
  const { data: payment } = await supabase.from("payments").select("*").eq("asaas_payment_id", paymentData.id).single();
  const statusMap = {
    PENDING: "pending",
    CONFIRMED: "confirmed",
    RECEIVED: "received",
    OVERDUE: "overdue",
    REFUNDED: "refunded",
    RECEIVED_IN_CASH: "received",
    REFUND_REQUESTED: "refunded",
    CHARGEBACK_REQUESTED: "refunded",
    CHARGEBACK_DISPUTE: "refunded",
    AWAITING_CHARGEBACK_REVERSAL: "refunded"
  };
  const newStatus = statusMap[paymentData.status] || "pending";
  if (payment) {
    await supabase.from("payments").update({
      status: newStatus,
      payment_date: paymentData.paymentDate || null,
      invoice_url: paymentData.invoiceUrl || null,
      bank_slip_url: paymentData.bankSlipUrl || null,
      metadata: paymentData
    }).eq("id", payment.id);
    if (newStatus === "confirmed" || newStatus === "received") {
      await supabase.from("subscriptions").update({ status: "active" }).eq("id", payment.subscription_id);
      const { data: referral } = await supabase.from("affiliate_referrals").select("*").eq("subscription_id", payment.subscription_id).single();
      if (referral) {
        await supabase.from("affiliate_referrals").update({
          status: "active",
          first_payment_at: referral.first_payment_at || (/* @__PURE__ */ new Date()).toISOString(),
          last_payment_at: (/* @__PURE__ */ new Date()).toISOString(),
          total_paid: supabase.raw(`total_paid + ${payment.amount}`)
        }).eq("id", referral.id);
        const { data: existingCommission } = await supabase.from("affiliate_commissions").select("*").eq("payment_id", payment.id).single();
        if (!existingCommission) {
          const commissionAmount = payment.amount * 0.2;
          await supabase.from("affiliate_commissions").insert({
            affiliate_id: referral.affiliate_id,
            referral_id: referral.id,
            payment_id: payment.id,
            amount: commissionAmount,
            payment_amount: payment.amount,
            commission_rate: 20,
            status: "available",
            available_at: (/* @__PURE__ */ new Date()).toISOString()
          });
          console.log(`Comiss\xE3o criada: R$ ${commissionAmount} para afiliado ${referral.affiliate_id}`);
        }
      }
    }
  } else {
    console.log("Pagamento n\xE3o encontrado no banco:", paymentData.id);
  }
}
async function handlePaymentOverdue(supabase, paymentData) {
  console.log("Pagamento vencido:", paymentData.id);
  const { data: payment } = await supabase.from("payments").select("*").eq("asaas_payment_id", paymentData.id).single();
  if (payment) {
    await supabase.from("payments").update({ status: "overdue" }).eq("id", payment.id);
    await supabase.from("subscriptions").update({ status: "past_due" }).eq("id", payment.subscription_id);
  }
}

export { asaas_post as default };
//# sourceMappingURL=asaas.post.mjs.map
