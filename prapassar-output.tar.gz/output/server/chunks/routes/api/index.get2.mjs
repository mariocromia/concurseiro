import { c as defineEventHandler, e as serverSupabaseClient, g as createError, i as getQuery } from '../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const index_get = defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient(event);
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) {
    throw createError({
      statusCode: 401,
      message: "Usu\xE1rio n\xE3o autenticado"
    });
  }
  const query = getQuery(event);
  const search = query.search;
  let queryBuilder = supabase.from("mindmaps").select("*").eq("user_id", user.id).order("updated_at", { ascending: false });
  if (search) {
    queryBuilder = queryBuilder.ilike("title", `%${search}%`);
  }
  const { data: mindmaps, error } = await queryBuilder;
  if (error) {
    throw createError({
      statusCode: 500,
      message: "Erro ao buscar mapas mentais",
      data: error
    });
  }
  return {
    success: true,
    data: mindmaps
  };
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
