import { c as defineEventHandler, f as serverSupabaseUser, g as createError, r as readBody, v as validateBody, e as serverSupabaseClient, o as updatePreferencesSchema } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const updatePreferences_post = defineEventHandler(async (event) => {
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "N\xE3o autenticado"
    });
  }
  const body = await readBody(event);
  const validated = validateBody(updatePreferencesSchema, body);
  try {
    const supabase = await serverSupabaseClient(event);
    const updateData = {
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (validated.push_notifications_enabled !== void 0) {
      updateData.push_notifications_enabled = validated.push_notifications_enabled;
    }
    if (validated.email_notifications_enabled !== void 0) {
      updateData.email_notifications_enabled = validated.email_notifications_enabled;
    }
    const { error: dbError } = await supabase.from("users").update(updateData).eq("id", user.id);
    if (dbError) {
      throw createError({
        statusCode: 500,
        message: dbError.message
      });
    }
    return {
      success: true,
      message: "Prefer\xEAncias atualizadas com sucesso",
      data: validated
    };
  } catch (error) {
    console.error("Error updating preferences:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao atualizar prefer\xEAncias"
    });
  }
});

export { updatePreferences_post as default };
//# sourceMappingURL=update-preferences.post.mjs.map
