import { c as defineEventHandler, f as serverSupabaseUser, g as createError, q as readFormData, e as serverSupabaseClient } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const uploadAvatar_post = defineEventHandler(async (event) => {
  var _a;
  console.log("\n=== [UPLOAD AVATAR] IN\xCDCIO DA REQUISI\xC7\xC3O ===");
  console.log("[UPLOAD AVATAR] Verificando autentica\xE7\xE3o...");
  const user = await serverSupabaseUser(event);
  const userId = (user == null ? void 0 : user.id) || (user == null ? void 0 : user.sub);
  console.log("[UPLOAD AVATAR] Resultado da autentica\xE7\xE3o:", {
    authenticated: !!user,
    userId: (user == null ? void 0 : user.id) || "UNDEFINED",
    userSub: (user == null ? void 0 : user.sub) || "UNDEFINED",
    finalUserId: userId || "UNDEFINED",
    userEmail: (user == null ? void 0 : user.email) || "UNDEFINED"
  });
  if (!user || !userId) {
    console.error("[UPLOAD AVATAR] \u274C ERRO: Usu\xE1rio n\xE3o autenticado ou ID ausente");
    throw createError({
      statusCode: 401,
      message: "N\xE3o autenticado"
    });
  }
  try {
    console.log("[UPLOAD AVATAR] Lendo FormData...");
    const formData = await readFormData(event);
    const file = formData.get("avatar");
    console.log("[UPLOAD AVATAR] \u2705 Usu\xE1rio autenticado:", {
      id: userId,
      email: user.email
    });
    if (!file || !(file instanceof File)) {
      console.error("[UPLOAD AVATAR] \u274C ERRO: Nenhum arquivo no FormData");
      throw createError({
        statusCode: 400,
        message: "Nenhum arquivo enviado. Por favor, selecione uma imagem."
      });
    }
    console.log("[UPLOAD AVATAR] \u2705 Arquivo recebido:", {
      name: file.name,
      type: file.type,
      size: file.size,
      sizeInMB: (file.size / (1024 * 1024)).toFixed(2) + "MB"
    });
    const MAX_FILE_SIZE = 2 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
      throw createError({
        statusCode: 400,
        message: `Imagem muito grande (${sizeMB}MB). O tamanho m\xE1ximo \xE9 2MB.`
      });
    }
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
      throw createError({
        statusCode: 400,
        message: "Formato inv\xE1lido. Use JPG, PNG, GIF ou WEBP."
      });
    }
    const supabase = await serverSupabaseClient(event);
    const fileExt = ((_a = file.name.split(".").pop()) == null ? void 0 : _a.toLowerCase()) || "jpg";
    const timestamp = Date.now();
    const fileName = `${userId}/avatar-${timestamp}.${fileExt}`;
    console.log("[UPLOAD AVATAR] \u2705 Nome do arquivo gerado:", {
      fileName,
      userFolder: userId,
      extension: fileExt,
      timestamp
    });
    console.log("[UPLOAD AVATAR] Convertendo arquivo para buffer...");
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    console.log("[UPLOAD AVATAR] \u2705 Buffer criado:", buffer.length, "bytes");
    console.log("[UPLOAD AVATAR] \u{1F680} Iniciando upload para Supabase Storage...");
    console.log("[UPLOAD AVATAR] Detalhes do upload:", {
      bucket: "avatars",
      path: fileName,
      contentType: file.type,
      size: buffer.length,
      upsert: true
    });
    const { data: uploadData, error: uploadError } = await supabase.storage.from("avatars").upload(fileName, buffer, {
      contentType: file.type,
      upsert: true,
      // Replace if exists
      cacheControl: "3600"
    });
    if (uploadError) {
      console.error("[UPLOAD AVATAR] \u274C ERRO NO UPLOAD:", {
        message: uploadError.message,
        statusCode: uploadError.statusCode,
        error: uploadError.error,
        details: uploadError
      });
      throw createError({
        statusCode: 500,
        message: "Erro ao fazer upload: " + uploadError.message
      });
    }
    console.log("[UPLOAD AVATAR] \u2705\u2705\u2705 UPLOAD BEM-SUCEDIDO!");
    console.log("[UPLOAD AVATAR] Dados do upload:", {
      path: uploadData.path,
      id: uploadData.id,
      fullPath: uploadData.fullPath
    });
    console.log("[UPLOAD AVATAR] Gerando URL p\xFAblica...");
    const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(fileName);
    const avatarUrl = urlData.publicUrl;
    console.log("[UPLOAD AVATAR] \u2705 URL p\xFAblica gerada:", avatarUrl);
    console.log("[UPLOAD AVATAR] Atualizando tabela users...");
    console.log("[UPLOAD AVATAR] Update payload:", {
      user_id: userId,
      avatar_url: avatarUrl,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    const { data: updateData, error: updateError } = await supabase.from("users").update({
      avatar_url: avatarUrl,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", userId).select();
    if (updateError) {
      console.error("[UPLOAD AVATAR] \u274C ERRO ao atualizar banco:", {
        message: updateError.message,
        code: updateError.code,
        details: updateError.details,
        hint: updateError.hint
      });
    } else {
      console.log("[UPLOAD AVATAR] \u2705 Banco de dados atualizado!");
      console.log("[UPLOAD AVATAR] Dados atualizados:", updateData);
    }
    console.log("[UPLOAD AVATAR] Atualizando metadados de autentica\xE7\xE3o...");
    const { error: authUpdateError } = await supabase.auth.updateUser({
      data: { avatar_url: avatarUrl }
    });
    if (authUpdateError) {
      console.error("[UPLOAD AVATAR] \u26A0\uFE0F Erro ao atualizar auth metadata:", authUpdateError);
    } else {
      console.log("[UPLOAD AVATAR] \u2705 Auth metadata atualizado");
    }
    console.log("[UPLOAD AVATAR] \u{1F389} PROCESSO COMPLETO!");
    console.log("=== [UPLOAD AVATAR] FIM DA REQUISI\xC7\xC3O ===\n");
    return {
      success: true,
      message: "Avatar atualizado com sucesso!",
      avatar_url: avatarUrl,
      file_name: fileName,
      file_size: file.size,
      file_type: file.type
    };
  } catch (error) {
    console.error("[UPLOAD AVATAR] \u274C Error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao fazer upload do avatar"
    });
  }
});

export { uploadAvatar_post as default };
//# sourceMappingURL=upload-avatar.post.mjs.map
