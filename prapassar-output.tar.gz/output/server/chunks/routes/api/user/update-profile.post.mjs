import { c as defineEventHandler, f as serverSupabaseUser, g as createError, r as readBody, v as validateBody, e as serverSupabaseClient, p as updateProfileSchema } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const updateProfile_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  console.log("\n=== [UPDATE PROFILE] IN\xCDCIO DA REQUISI\xC7\xC3O ===");
  console.log("[UPDATE PROFILE] Verificando autentica\xE7\xE3o...");
  const user = await serverSupabaseUser(event);
  console.log("[UPDATE PROFILE] User object COMPLETO:", user);
  console.log("[UPDATE PROFILE] User keys:", user ? Object.keys(user) : []);
  const userId = (user == null ? void 0 : user.id) || (user == null ? void 0 : user.sub);
  console.log("[UPDATE PROFILE] Resultado da autentica\xE7\xE3o:", {
    authenticated: !!user,
    userId: (user == null ? void 0 : user.id) || "UNDEFINED",
    userSub: (user == null ? void 0 : user.sub) || "UNDEFINED",
    finalUserId: userId || "UNDEFINED",
    userEmail: (user == null ? void 0 : user.email) || "UNDEFINED",
    userIdType: typeof (user == null ? void 0 : user.id),
    userSubType: typeof (user == null ? void 0 : user.sub)
  });
  if (!user) {
    console.error("[UPDATE PROFILE] \u274C ERRO: Usu\xE1rio n\xE3o autenticado");
    throw createError({
      statusCode: 401,
      message: "N\xE3o autenticado"
    });
  }
  if (!userId || userId === "undefined" || typeof userId !== "string") {
    console.error("[UPDATE PROFILE] \u274C ERRO CR\xCDTICO: User ID inv\xE1lido!", {
      userId: user.id,
      userSub: user.sub,
      finalUserId: userId,
      type: typeof userId,
      stringified: JSON.stringify(userId)
    });
    throw createError({
      statusCode: 400,
      message: "ID de usu\xE1rio inv\xE1lido"
    });
  }
  console.log("[UPDATE PROFILE] \u2705 Usu\xE1rio autenticado:", {
    id: userId,
    email: user.email
  });
  console.log("[UPDATE PROFILE] Lendo body da requisi\xE7\xE3o...");
  const body = await readBody(event);
  console.log("[UPDATE PROFILE] \u2705 Body recebido:", {
    hasFullName: !!body.full_name,
    fullName: body.full_name,
    hasPhone: !!body.phone,
    phone: body.phone,
    hasAvatarUrl: !!body.avatar_url,
    avatarUrl: ((_a = body.avatar_url) == null ? void 0 : _a.substring(0, 50)) + "..."
    // Truncate URL
  });
  console.log("[UPDATE PROFILE] Validando dados com Zod...");
  const validated = validateBody(updateProfileSchema, body);
  console.log("[UPDATE PROFILE] \u2705 Dados validados:", {
    full_name: validated.full_name,
    phone: validated.phone || "NULL",
    avatar_url: ((_b = validated.avatar_url) == null ? void 0 : _b.substring(0, 50)) + "..." || "NULL"
  });
  try {
    console.log("[UPDATE PROFILE] Criando cliente Supabase...");
    const supabase = await serverSupabaseClient(event);
    console.log("[UPDATE PROFILE] \u2705 Cliente Supabase criado");
    console.log("[UPDATE PROFILE] \u{1F504} Atualizando Auth metadata...");
    console.log("[UPDATE PROFILE] Auth payload:", {
      name: validated.full_name,
      phone: validated.phone || "NULL",
      avatar_url: validated.avatar_url || "NULL"
    });
    const { data: authData, error: authError } = await supabase.auth.updateUser({
      data: {
        name: validated.full_name,
        avatar_url: validated.avatar_url,
        phone: validated.phone
      }
    });
    if (authError) {
      console.error("[UPDATE PROFILE] \u274C ERRO ao atualizar Auth:", {
        message: authError.message,
        status: authError.status,
        name: authError.name
      });
      throw createError({
        statusCode: 500,
        message: "Erro ao atualizar autentica\xE7\xE3o: " + authError.message
      });
    }
    console.log("[UPDATE PROFILE] \u2705 Auth metadata atualizado!");
    console.log("[UPDATE PROFILE] Auth data:", (_c = authData == null ? void 0 : authData.user) == null ? void 0 : _c.id);
    console.log("[UPDATE PROFILE] \u{1F504} Atualizando tabela users...");
    console.log("[UPDATE PROFILE] Database update payload:", {
      user_id: userId,
      full_name: validated.full_name,
      phone: validated.phone || "NULL",
      avatar_url: validated.avatar_url || "NULL",
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    const { data: dbData, error: dbError } = await supabase.from("users").update({
      full_name: validated.full_name,
      phone: validated.phone,
      avatar_url: validated.avatar_url,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", userId).select().single();
    if (dbError) {
      console.error("[UPDATE PROFILE] \u274C ERRO ao atualizar banco:", {
        message: dbError.message,
        code: dbError.code,
        details: dbError.details,
        hint: dbError.hint
      });
      throw createError({
        statusCode: 500,
        message: "Erro ao salvar no banco de dados: " + dbError.message
      });
    }
    console.log("[UPDATE PROFILE] \u2705\u2705\u2705 Banco de dados atualizado!");
    console.log("[UPDATE PROFILE] Dados salvos:", {
      id: dbData.id,
      full_name: dbData.full_name,
      phone: dbData.phone,
      avatar_url: ((_d = dbData.avatar_url) == null ? void 0 : _d.substring(0, 50)) + "..."
    });
    console.log("[UPDATE PROFILE] \u{1F389} PROCESSO COMPLETO!");
    console.log("=== [UPDATE PROFILE] FIM DA REQUISI\xC7\xC3O ===\n");
    return {
      success: true,
      message: "Perfil atualizado com sucesso",
      data: dbData
    };
  } catch (error) {
    console.error("[UPDATE PROFILE] \u274C\u274C\u274C ERRO CAPTURADO:", {
      errorMessage: error.message,
      errorStack: error.stack,
      errorStatusCode: error.statusCode,
      errorName: error.name,
      fullError: JSON.stringify(error, null, 2)
    });
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      message: error.message || "Erro ao atualizar perfil"
    });
  }
});

export { updateProfile_post as default };
//# sourceMappingURL=update-profile.post.mjs.map
