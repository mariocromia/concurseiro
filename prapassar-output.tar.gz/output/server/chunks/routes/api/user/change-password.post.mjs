import { c as defineEventHandler, f as serverSupabaseUser, g as createError, r as readBody, v as validateBody, e as serverSupabaseClient, n as changePasswordSchema } from '../../../_/nitro.mjs';
import 'zod';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@upstash/redis';
import '@upstash/ratelimit';
import '@supabase/ssr';
import 'node:path';
import 'node:crypto';

const changePassword_post = defineEventHandler(async (event) => {
  const user = await serverSupabaseUser(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      message: "N\xE3o autenticado"
    });
  }
  const body = await readBody(event);
  const validated = validateBody(changePasswordSchema, body);
  try {
    const supabase = await serverSupabaseClient(event);
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: validated.current_password
    });
    if (signInError) {
      throw createError({
        statusCode: 401,
        message: "Senha atual incorreta"
      });
    }
    const { error: updateError } = await supabase.auth.updateUser({
      password: validated.new_password
    });
    if (updateError) {
      throw createError({
        statusCode: 500,
        message: updateError.message
      });
    }
    return {
      success: true,
      message: "Senha alterada com sucesso"
    };
  } catch (error) {
    console.error("Error changing password:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Erro ao alterar senha"
    });
  }
});

export { changePassword_post as default };
//# sourceMappingURL=change-password.post.mjs.map
